package com.docstore.service.aws;

import javax.mail.Session;
import javax.mail.internet.MimeMessage;

public interface AWSEmailService {
	
	public void sendMail(Session session, MimeMessage message);

}
