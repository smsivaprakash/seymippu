package com.docstore.service.aws;

import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service("awsEmailService")
public class AWSEmailServiceImpl implements AWSEmailService{
	
	@Value("${aws.smtp.host:''}")
	private String smtpHost;
	
	@Value("${aws.smtp.username:''}")
	private String smtpUsername;
	
	@Value("${aws.smtp.password:''}")
	private String smtpPassword;

	public void sendMail(Session session, MimeMessage message) {
		Transport transport = null;
        try
        {
        	transport = session.getTransport();
            System.out.println("sending email through docucloud...");
            transport.connect(smtpHost, smtpUsername, smtpPassword);
            transport.sendMessage(message, message.getAllRecipients());
            System.out.println("Email sent successfully");
        }
        catch (Exception ex) {
            System.out.println("The email was not sent.");
            System.out.println("Error message: " + ex.getMessage());
        }
        finally
        {
            try {
				transport.close();
			} catch (MessagingException e) {
				System.out.println("Error while terminating mail session");
			}        	
        }
		
	}

}
