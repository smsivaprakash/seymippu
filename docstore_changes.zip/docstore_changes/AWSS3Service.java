package com.docstore.service.aws;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;

public interface AWSS3Service {
	
	public boolean createBucket(String bucketName) throws AmazonServiceException, AmazonClientException;

}
