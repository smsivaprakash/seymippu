package com.docstore.service.aws;

import java.io.InputStream;
import java.util.Map;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.S3ObjectSummary;

public interface AWSS3Service {
	
	public boolean createBucket(String bucketName) throws AmazonServiceException, AmazonClientException;
	
	public boolean deleteBucket(String bucketName) throws AmazonServiceException, AmazonClientException;
	
	public Map<S3ObjectSummary, ObjectMetadata> getObjectSummaryList(String bucketName, String prefix) throws AmazonServiceException, AmazonClientException;
	
	public boolean uploadObject(String uploadDirectory, String key, String contentType, InputStream inputStream) throws AmazonServiceException, AmazonClientException, InterruptedException;
	
	public boolean downloadObject(String bucketName, String prefix, String key, String downloadPath) throws AmazonServiceException, AmazonClientException, InterruptedException;

}
