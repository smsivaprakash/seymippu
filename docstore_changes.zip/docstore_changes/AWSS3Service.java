package com.docstore.service.aws;

import java.util.List;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.model.S3ObjectSummary;

public interface AWSS3Service {
	
	public boolean createBucket(String bucketName) throws AmazonServiceException, AmazonClientException;
	
	public boolean deleteBucket(String bucketName) throws AmazonServiceException, AmazonClientException;
	
	public List<S3ObjectSummary> getObjectSummaryList(String bucketName, String prefix) throws AmazonServiceException, AmazonClientException;

}
