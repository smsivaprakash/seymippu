package com.docstore.service.aws;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.CreateBucketRequest;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ListVersionsRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.amazonaws.services.s3.model.S3VersionSummary;
import com.amazonaws.services.s3.model.VersionListing;


@Service("awsS3Service")
public class AWSS3ServiceImpl implements AWSS3Service{

	@Autowired
	AWSUtil awsUtil;

	public boolean createBucket(String bucketName) throws AmazonServiceException, AmazonClientException {
		AmazonS3 s3client = awsUtil.getConfiguration();
		boolean bucketCreated = false;
		if(!(s3client.doesBucketExist(bucketName)))
		{
			s3client.createBucket(new CreateBucketRequest(bucketName));
			System.out.println("bucket created successfully with name: "+bucketName);
			bucketCreated = true;
		}
		else{
			System.out.println("bucket: "+bucketName+" already exists");
		}
		//String bucketLocation = s3client.getBucketLocation(new GetBucketLocationRequest(bucketName));
		//System.out.println("bucket location = " + bucketLocation);

		return bucketCreated;
	}

	public boolean deleteBucket(String bucketName)
			throws AmazonServiceException, AmazonClientException {
		boolean isBucketDeleted = false;
		AmazonS3 s3client = awsUtil.getConfiguration();
		System.out.println("Deleting S3 bucket: " + bucketName);
		ObjectListing objectListing = s3client.listObjects(bucketName);

		while (true) {
			for (Iterator<?> iterator = objectListing.getObjectSummaries().iterator(); iterator.hasNext(); ) {
				S3ObjectSummary objectSummary = (S3ObjectSummary) iterator.next();
				s3client.deleteObject(bucketName, objectSummary.getKey());
			}

			if (objectListing.isTruncated()) {
				objectListing = s3client.listNextBatchOfObjects(objectListing);
			} else {
				break;
			}
		};
		VersionListing list = s3client.listVersions(new ListVersionsRequest().withBucketName(bucketName));
		for ( Iterator<?> iterator = list.getVersionSummaries().iterator(); iterator.hasNext(); ) {
			S3VersionSummary s = (S3VersionSummary)iterator.next();
			s3client.deleteVersion(bucketName, s.getKey(), s.getVersionId());
		}
		s3client.deleteBucket(bucketName);
		isBucketDeleted = true;
		return isBucketDeleted;
	}

	public List<S3ObjectSummary> getObjectSummaryList(String bucketName, String prefix)
			throws AmazonServiceException, AmazonClientException {
		AmazonS3 s3client = awsUtil.getConfiguration();
		ObjectListing objectListing = null;
		if(null != prefix && !"".equals(prefix)){
			objectListing = s3client.listObjects(new ListObjectsRequest().withBucketName(bucketName).withPrefix(prefix));
		}
		else{
			objectListing = s3client.listObjects(new ListObjectsRequest().withBucketName(bucketName));
		}
		return objectListing.getObjectSummaries();
	}
}
