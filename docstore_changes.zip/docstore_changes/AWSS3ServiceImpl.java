package com.docstore.service.aws;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.BucketLifecycleConfiguration.Rule;
import com.amazonaws.services.s3.model.AmazonS3Exception;
import com.amazonaws.services.s3.model.BucketLifecycleConfiguration;
import com.amazonaws.services.s3.model.BucketVersioningConfiguration;
import com.amazonaws.services.s3.model.CreateBucketRequest;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ListVersionsRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.amazonaws.services.s3.model.S3VersionSummary;
import com.amazonaws.services.s3.model.SetBucketVersioningConfigurationRequest;
import com.amazonaws.services.s3.model.VersionListing;
import com.amazonaws.services.s3.transfer.Download;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.amazonaws.services.s3.transfer.Upload;


@Service("awsS3Service")
public class AWSS3ServiceImpl implements AWSS3Service{

	@Autowired
	AWSUtil awsUtil;

	public boolean createBucket(String bucketName) throws AmazonServiceException, AmazonClientException {
		AmazonS3 s3client = awsUtil.getConfiguration();
		boolean bucketCreated = false;
		if(!(s3client.doesBucketExist(bucketName)))
		{
			s3client.createBucket(new CreateBucketRequest(bucketName));
			System.out.println("bucket created successfully with name: "+bucketName);

			BucketVersioningConfiguration configuration = new BucketVersioningConfiguration().withStatus("Enabled");
			SetBucketVersioningConfigurationRequest setBucketVersioningConfigurationRequest = 
					new SetBucketVersioningConfigurationRequest(bucketName,configuration);
			s3client.setBucketVersioningConfiguration(setBucketVersioningConfigurationRequest);
			bucketCreated = true;
		}
		else{
			System.out.println("bucket: "+bucketName+" already exists");
		}
		return bucketCreated;
	}

	public boolean deleteBucket(String bucketName)
			throws AmazonServiceException, AmazonClientException {
		boolean isBucketDeleted = false;
		AmazonS3 s3client = awsUtil.getConfiguration();
		System.out.println("Deleting S3 bucket: " + bucketName);
		ObjectListing objectListing = s3client.listObjects(bucketName);

		while (true) {
			for (Iterator<?> iterator = objectListing.getObjectSummaries().iterator(); iterator.hasNext(); ) {
				S3ObjectSummary objectSummary = (S3ObjectSummary) iterator.next();
				s3client.deleteObject(bucketName, objectSummary.getKey());
			}

			if (objectListing.isTruncated()) {
				objectListing = s3client.listNextBatchOfObjects(objectListing);
			} else {
				break;
			}
		};
		VersionListing list = s3client.listVersions(new ListVersionsRequest().withBucketName(bucketName));
		for ( Iterator<?> iterator = list.getVersionSummaries().iterator(); iterator.hasNext(); ) {
			S3VersionSummary s = (S3VersionSummary)iterator.next();
			s3client.deleteVersion(bucketName, s.getKey(), s.getVersionId());
		}
		s3client.deleteBucket(bucketName);
		isBucketDeleted = true;
		return isBucketDeleted;
	}

	public Map<S3ObjectSummary, ObjectMetadata> getObjectSummaryList(String bucketName, String prefix)
			throws AmazonServiceException, AmazonClientException {
		AmazonS3 s3client = awsUtil.getConfiguration();
		System.out.println("fetching objects from the bucket : "+bucketName+" prefix: "+prefix);
		Map<S3ObjectSummary, ObjectMetadata> objectMap = null;
		ObjectListing objectListing = null;
		if(null == prefix || "".equals(prefix.trim())){
			System.out.println("prefix is empty");
			objectListing = s3client.listObjects(new ListObjectsRequest().withBucketName(bucketName).withPrefix(prefix));
			System.out.println("fetching done");
			if(null != objectListing.getObjectSummaries() && !objectListing.getObjectSummaries().isEmpty()){
				objectMap = new LinkedHashMap<S3ObjectSummary, ObjectMetadata>();
				for(S3ObjectSummary objectSummary : objectListing.getObjectSummaries()){
					String key = objectSummary.getKey();
					if(key.split("/").length == 1){
						ObjectMetadata objectMetadata = s3client.getObjectMetadata(bucketName, key);
						objectSummary.setKey(key.split("/")[0]);
						objectMap.put(objectSummary, objectMetadata);
					}
				}
			}
		}
		else{
			objectListing = s3client.listObjects(new ListObjectsRequest().withBucketName(bucketName).withPrefix(prefix+"/").withMarker(prefix+"/"));
			if(null != objectListing.getObjectSummaries() && !objectListing.getObjectSummaries().isEmpty()){
				objectMap = new LinkedHashMap<S3ObjectSummary, ObjectMetadata>();
				for(S3ObjectSummary objectSummary : objectListing.getObjectSummaries()){
					String key = objectSummary.getKey();
					String actualValue = objectSummary.getKey().substring(prefix.length()+1);
					if(actualValue.split("/").length == 1){
						ObjectMetadata objectMetadata = s3client.getObjectMetadata(bucketName, key);
						objectSummary.setKey(actualValue.split("/")[0]);
						objectMap.put(objectSummary, objectMetadata);
					}
				}
			}
		}
		return objectMap;
	}

	public boolean uploadObject(String uploadDirectory, String key, String contentType, InputStream inputStream, long contentLength)
			throws AmazonServiceException, AmazonClientException, InterruptedException {
		boolean isUploadDone = false;
		AmazonS3 s3client = awsUtil.getConfiguration();
		TransferManager transferManager = new TransferManager(s3client);
		ObjectMetadata objectMetadata = new ObjectMetadata();
		objectMetadata.setContentType(contentType);
		objectMetadata.setContentLength(contentLength);
		Upload upload = transferManager.upload(uploadDirectory, key, inputStream, objectMetadata);
		upload.waitForCompletion();
		if(upload.isDone()){
			System.out.println("file "+key+" uploaded successfully");
			isUploadDone = true;
		}
		return isUploadDone;
	}

	public boolean downloadObject(String bucketName, String prefix, String key, String downloadPath)
			throws AmazonServiceException, AmazonClientException, InterruptedException {
		boolean isDownloadDone = false;
		AmazonS3 s3client = awsUtil.getConfiguration();
		File file = new File(downloadPath+"\\"+key);
		if(!"".equals(prefix.trim())){
			key = prefix + "/" + key;
		}
		TransferManager transferManager = new TransferManager(s3client);
		Download download = transferManager.download(bucketName, key, file);
		download.waitForCompletion();
		if(download.isDone()){
			System.out.println("file "+file.getName()+" downloaded successfully");
			isDownloadDone = true;
		}
		return isDownloadDone;
	}

	public boolean createFolder(String bucketName, String folderKey) throws AmazonServiceException, AmazonClientException, 
	InterruptedException {
		boolean isFolderCreated = false;
		AmazonS3 s3client = awsUtil.getConfiguration();
		TransferManager transferManager = new TransferManager(s3client);
		InputStream inputStream = new ByteArrayInputStream(new byte[0]);
		ObjectMetadata objectMetadata = new ObjectMetadata();
		objectMetadata.setContentLength(0);
		objectMetadata.setContentType("binary/octet-stream");
		Upload upload = transferManager.upload(bucketName, folderKey+"/", inputStream, objectMetadata);
		upload.waitForCompletion();
		if(upload.isDone()){
			System.out.println("folder "+folderKey+" created successfully");
			isFolderCreated = true;
		}
		return isFolderCreated;
	}

	public List<S3VersionSummary> getObjectVersionsList(String bucketName,
			String prefix, String key) throws AmazonServiceException,
			AmazonClientException {
		AmazonS3 s3client = awsUtil.getConfiguration();
		if(null == prefix || "".equals(prefix.trim())){
			prefix = key;
		}
		else{
			prefix = prefix + "/" + key;
		}
		List<S3VersionSummary> versionSummaryList = new ArrayList<S3VersionSummary>();
		ListVersionsRequest request = new ListVersionsRequest().withBucketName(bucketName).withPrefix(prefix).withMaxResults(5);
		VersionListing versionListing;            
		do {
			versionListing = s3client.listVersions(request);
			if(null != versionListing.getVersionSummaries() && !versionListing.getVersionSummaries().isEmpty()){
				versionSummaryList.addAll(versionListing.getVersionSummaries());
			}
			request.setKeyMarker(versionListing.getNextKeyMarker());
			request.setVersionIdMarker(versionListing.getNextVersionIdMarker());
		} while (versionListing.isTruncated());
		return versionSummaryList;
	}

	public List<Rule> fetchLifeCycleRules(String bucketName) {
		AmazonS3 s3Client = awsUtil.getConfiguration();
		BucketLifecycleConfiguration configuration = s3Client.getBucketLifecycleConfiguration(bucketName);
		if(null != configuration && null != configuration.getRules()){
			return configuration.getRules();
		}
		else{
			return null;
		}
	}

	public boolean addLifeCycleRule(Rule rule, String bucketName) {
		boolean isRuleAdded = true;
		AmazonS3 s3Client = awsUtil.getConfiguration();
		try{
			BucketLifecycleConfiguration configuration = s3Client.getBucketLifecycleConfiguration(bucketName);
			if(null != configuration){
				System.out.println("creating new rule");
				configuration.getRules().add(rule);
			}
			else{
				configuration =  new BucketLifecycleConfiguration().withRules(Arrays.asList(rule));
			}
			s3Client.setBucketLifecycleConfiguration(bucketName, configuration);
		}
		catch(AmazonS3Exception e){
			isRuleAdded = false;
		}
		return isRuleAdded;
	}

	public boolean editLifeCycleRule(Rule editedRule, String bucketName, String existingRuleId) {
		boolean isRuleEdited = true;
		AmazonS3 s3Client = awsUtil.getConfiguration();
		try{
			BucketLifecycleConfiguration configuration = s3Client.getBucketLifecycleConfiguration(bucketName);
			if(null != configuration){
				System.out.println("editing existing rule");
				List<Rule> ruleList = configuration.getRules();
				if(null != ruleList && !ruleList.isEmpty()){
					for(Rule rule : ruleList){
						if(rule.getId().equals(existingRuleId)){
							ruleList.set(ruleList.indexOf(rule), editedRule);
							break;
						}
					}
					configuration.setRules(ruleList);
					s3Client.setBucketLifecycleConfiguration(bucketName, configuration);
				}
			}
		}
		catch(AmazonS3Exception e){
			isRuleEdited = false;
		}
		return isRuleEdited;
	}

	public boolean deleteLifeCycleRule(String ruleId, String bucketName) {
		boolean isRuleDeleted = true;
		AmazonS3 s3Client = awsUtil.getConfiguration();
		try{
			BucketLifecycleConfiguration configuration = s3Client.getBucketLifecycleConfiguration(bucketName);
			if(null != configuration){
				System.out.println("deleting rule");
				List<Rule> ruleList = configuration.getRules();
				if(null != ruleList && !ruleList.isEmpty()){
					for(Rule rule : ruleList){
						if(rule.getId().equals(ruleId)){
							isRuleDeleted = ruleList.remove(rule);
							break;
						}
					}
					if(ruleList.isEmpty()){
						s3Client.deleteBucketLifecycleConfiguration(bucketName);
					}
					else{
						configuration.setRules(ruleList);
						s3Client.setBucketLifecycleConfiguration(bucketName, configuration);
					}
				}
			}
		}
		catch(AmazonS3Exception e){
			isRuleDeleted = false;
		}
		return isRuleDeleted;
	}

	public boolean createFile(String bucketName, String key, File file)
			throws AmazonServiceException, AmazonClientException, InterruptedException {
		boolean isFileCreated = false;
		AmazonS3 s3client = awsUtil.getConfiguration();
		TransferManager transferManager = new TransferManager(s3client);
		Upload upload = transferManager.upload(bucketName, key, file);
		upload.waitForCompletion();
		if(upload.isDone()){
			System.out.println("file "+key+" created successfully");
			isFileCreated = true;
		}
		return isFileCreated;
	}
}
