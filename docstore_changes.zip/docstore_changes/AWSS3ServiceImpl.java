package com.docstore.service.aws;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.CreateBucketRequest;


@Service("awsS3Service")
public class AWSS3ServiceImpl implements AWSS3Service{

	@Autowired
	AWSUtil awsUtil;

	public boolean createBucket(String bucketName) throws AmazonServiceException, AmazonClientException {
		AmazonS3 s3client = awsUtil.getConfiguration();
		boolean bucketCreated = false;

		//TODO delete
		System.out.println("region: "+s3client.getRegion().toString());
		if(!(s3client.doesBucketExist(bucketName)))
		{
			s3client.createBucket(new CreateBucketRequest(bucketName));
			System.out.println("bucket created successfully with name: "+bucketName);
			bucketCreated = true;
		}
		else{
			System.out.println("bucket: "+bucketName+" already exists");
		}
		//String bucketLocation = s3client.getBucketLocation(new GetBucketLocationRequest(bucketName));
		//System.out.println("bucket location = " + bucketLocation);

		return bucketCreated;
	}

	public boolean deleteBucket(String bucketName)
			throws AmazonServiceException, AmazonClientException {
		// TODO Auto-generated method stub
		return false;
	}

}
