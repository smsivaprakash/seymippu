package com.docstore.service.aws;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.CreateBucketRequest;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ListVersionsRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.amazonaws.services.s3.model.S3VersionSummary;
import com.amazonaws.services.s3.model.VersionListing;
import com.amazonaws.services.s3.transfer.Download;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.amazonaws.services.s3.transfer.Upload;


@Service("awsS3Service")
public class AWSS3ServiceImpl implements AWSS3Service{

	@Autowired
	AWSUtil awsUtil;

	public boolean createBucket(String bucketName) throws AmazonServiceException, AmazonClientException {
		AmazonS3 s3client = awsUtil.getConfiguration();
		boolean bucketCreated = false;
		if(!(s3client.doesBucketExist(bucketName)))
		{
			s3client.createBucket(new CreateBucketRequest(bucketName));
			System.out.println("bucket created successfully with name: "+bucketName);
			bucketCreated = true;
		}
		else{
			System.out.println("bucket: "+bucketName+" already exists");
		}
		//String bucketLocation = s3client.getBucketLocation(new GetBucketLocationRequest(bucketName));
		//System.out.println("bucket location = " + bucketLocation);

		return bucketCreated;
	}

	public boolean deleteBucket(String bucketName)
			throws AmazonServiceException, AmazonClientException {
		boolean isBucketDeleted = false;
		AmazonS3 s3client = awsUtil.getConfiguration();
		System.out.println("Deleting S3 bucket: " + bucketName);
		ObjectListing objectListing = s3client.listObjects(bucketName);

		while (true) {
			for (Iterator<?> iterator = objectListing.getObjectSummaries().iterator(); iterator.hasNext(); ) {
				S3ObjectSummary objectSummary = (S3ObjectSummary) iterator.next();
				s3client.deleteObject(bucketName, objectSummary.getKey());
			}

			if (objectListing.isTruncated()) {
				objectListing = s3client.listNextBatchOfObjects(objectListing);
			} else {
				break;
			}
		};
		VersionListing list = s3client.listVersions(new ListVersionsRequest().withBucketName(bucketName));
		for ( Iterator<?> iterator = list.getVersionSummaries().iterator(); iterator.hasNext(); ) {
			S3VersionSummary s = (S3VersionSummary)iterator.next();
			s3client.deleteVersion(bucketName, s.getKey(), s.getVersionId());
		}
		s3client.deleteBucket(bucketName);
		isBucketDeleted = true;
		return isBucketDeleted;
	}

	public Map<S3ObjectSummary, ObjectMetadata> getObjectSummaryList(String bucketName, String prefix)
			throws AmazonServiceException, AmazonClientException {
		AmazonS3 s3client = awsUtil.getConfiguration();
		System.out.println("fetching objects from the bucket : "+bucketName+" prefix: "+prefix);
		Map<S3ObjectSummary, ObjectMetadata> objectMap = null;
		ObjectListing objectListing = null;
		if(null == prefix || "".equals(prefix.trim())){
			System.out.println("prefix is empty");
			objectListing = s3client.listObjects(new ListObjectsRequest().withBucketName(bucketName).withPrefix(prefix));
			System.out.println("fetching done");
			if(null != objectListing.getObjectSummaries() && !objectListing.getObjectSummaries().isEmpty()){
				objectMap = new LinkedHashMap<S3ObjectSummary, ObjectMetadata>();
				for(S3ObjectSummary objectSummary : objectListing.getObjectSummaries()){
					String key = objectSummary.getKey();
					if(key.split("/").length == 1){
						ObjectMetadata objectMetadata = s3client.getObjectMetadata(bucketName, key);
						objectSummary.setKey(key.split("/")[0]);
						objectMap.put(objectSummary, objectMetadata);
					}
				}
			}
		}
		else{
			objectListing = s3client.listObjects(new ListObjectsRequest().withBucketName(bucketName).withPrefix(prefix+"/").withMarker(prefix+"/"));
			if(null != objectListing.getObjectSummaries() && !objectListing.getObjectSummaries().isEmpty()){
				objectMap = new LinkedHashMap<S3ObjectSummary, ObjectMetadata>();
				for(S3ObjectSummary objectSummary : objectListing.getObjectSummaries()){
					String key = objectSummary.getKey();
					String actualValue = objectSummary.getKey().substring(prefix.length()+1);
					if(actualValue.split("/").length == 1){
						ObjectMetadata objectMetadata = s3client.getObjectMetadata(bucketName, key);
						objectSummary.setKey(actualValue.split("/")[0]);
						objectMap.put(objectSummary, objectMetadata);
					}
				}
			}
		}
		return objectMap;
	}

	public boolean uploadObject(String uploadDirectory, String key, String contentType, InputStream inputStream, long contentLength)
			throws AmazonServiceException, AmazonClientException, InterruptedException {
		boolean isUploadDone = false;
		AmazonS3 s3client = awsUtil.getConfiguration();
		TransferManager transferManager = new TransferManager(s3client);
		ObjectMetadata objectMetadata = new ObjectMetadata();
		objectMetadata.setContentType(contentType);
		objectMetadata.setContentLength(contentLength);
		Upload upload = transferManager.upload(uploadDirectory, key, inputStream, objectMetadata);
		upload.waitForCompletion();
		if(upload.isDone()){
			System.out.println("file "+key+" uploaded successfully");
			isUploadDone = true;
		}
		return isUploadDone;
	}

	public boolean downloadObject(String bucketName, String prefix, String key, String downloadPath)
			throws AmazonServiceException, AmazonClientException, InterruptedException {
		boolean isDownloadDone = false;
		AmazonS3 s3client = awsUtil.getConfiguration();
		File file = new File(downloadPath+"\\"+key);
		if(!"".equals(prefix.trim())){
			key = prefix + "/" + key;
		}
		TransferManager transferManager = new TransferManager(s3client);
		Download download = transferManager.download(bucketName, key, file);
		download.waitForCompletion();
		if(download.isDone()){
			System.out.println("file "+file.getName()+" downloaded successfully");
			isDownloadDone = true;
		}
		return isDownloadDone;
	}

	public boolean createFolder(String bucketName, String folderKey) throws AmazonServiceException, AmazonClientException, 
		InterruptedException {
		boolean isFolderCreated = false;
		AmazonS3 s3client = awsUtil.getConfiguration();
		TransferManager transferManager = new TransferManager(s3client);
		InputStream inputStream = new ByteArrayInputStream(new byte[0]);
		ObjectMetadata objectMetadata = new ObjectMetadata();
		objectMetadata.setContentLength(0);
		Upload upload = transferManager.upload(bucketName, folderKey+"/", inputStream, objectMetadata);
		upload.waitForCompletion();
		if(upload.isDone()){
			System.out.println("folder "+folderKey+" created successfully");
			isFolderCreated = true;
		}
		return isFolderCreated;
	}
}
