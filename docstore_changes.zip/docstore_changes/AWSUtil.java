package com.docstore.service.aws;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.Protocol;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;

@Component
public class AWSUtil {
	
	@Value("${aws.accessKey:''}")
	private String accessKey;
	
	@Value("${aws.secretKey:''}")
	private String secretKey;
	
	public AmazonS3 getConfiguration(){
		AWSCredentials awsCredentials = new BasicAWSCredentials(accessKey, secretKey);
		ClientConfiguration clientConfiguration = new ClientConfiguration();
		clientConfiguration.setProtocol(Protocol.HTTP);
//		clientConfiguration.setProxyHost("proxy.cognizant.com");
//		clientConfiguration.setProxyPort(6050);
		final AmazonS3 s3client = new AmazonS3Client(awsCredentials, clientConfiguration);
		s3client.setRegion(Region.getRegion(Regions.AP_SOUTH_1));
		return s3client;
	}
	
}
