package com.docstore.core.domain;

import java.io.Serializable;

public class AccessPermission implements Serializable{

	private static final long serialVersionUID = 6865138287354272127L;
	
	private Integer docstoreId;
	
	private Integer userId;
	
	private AccessType accessType;

	public Integer getDocstoreId() {
		return docstoreId;
	}

	public void setDocstoreId(Integer docstoreId) {
		this.docstoreId = docstoreId;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public AccessType getAccessType() {
		return accessType;
	}

	public void setAccessType(AccessType accessType) {
		this.accessType = accessType;
	}

}
