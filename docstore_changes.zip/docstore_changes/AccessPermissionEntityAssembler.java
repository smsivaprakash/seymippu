package com.docstore.service.assembler;

import org.springframework.stereotype.Component;

import com.docstore.core.domain.AccessPermission;
import com.docstore.core.entity.TAccessPermission;
import com.docstore.core.entity.TAccessPermissionId;
import com.docstore.core.entity.TAccessType;
import com.docstore.core.entity.TDocstore;
import com.docstore.core.entity.TUsr;

@Component
public class AccessPermissionEntityAssembler {
	
	public TAccessPermission mapAccessPermissionEntityToModel(AccessPermission accessPermission){
		TAccessPermission tAccessPermission = null;
		if(null != accessPermission){
			tAccessPermission = new TAccessPermission();
			TAccessPermissionId tAccessPermissionId = new TAccessPermissionId();
			tAccessPermissionId.setDocstoreId(accessPermission.getDocstoreId());
			tAccessPermissionId.setUsrId(accessPermission.getUserId());
			tAccessPermission.settAccessPermissionId(tAccessPermissionId);
			
			TDocstore tDocstore = new TDocstore();
			tDocstore.setDocstoreId(accessPermission.getDocstoreId());
			tAccessPermission.settDocstore(tDocstore);
			
			TUsr tUsr = new TUsr();
			tUsr.setUsrId(accessPermission.getUserId());
			tAccessPermission.settUsr(tUsr);
			
			TAccessType tAccessType = new TAccessType();
			tAccessType.setAccessTypeId(accessPermission.getAccessType().getId());
			tAccessPermission.settAccessType(tAccessType);
		}
		return tAccessPermission;
	}

}
