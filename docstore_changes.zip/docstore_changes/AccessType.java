package com.docstore.core.domain;

public enum AccessType {
	
	DEFAULT(1), LIMITED(2), FULLACCESS(3);

	private Integer id;
	
	private AccessType(Integer id) {
		this.id=id;
	}

	public Integer getId(){
		return id;
	}
	
	/**
	 * Gets the access type.
	 *
	 * @param id the id
	 * @return the access type
	 */
	public static AccessType getAccessType(Integer id) {
		for(AccessType accessType : AccessType.values()) { 
	        if(accessType.getId().equals(id)){
	        	return accessType;
	        }
	     }
		return null;
	}

}
