package com.docstore.portal.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.docstore.core.domain.UserDetails;
import com.docstore.core.exception.AuthenticationServiceException;
import com.docstore.core.exception.BusinessException;
import com.docstore.service.authentication.AuthenticationService;

@Controller
@RequestMapping(value = "/auth")
public class AuthenticationController {

	@Autowired
	AuthenticationService authenticationService;

	Integer loggedInUsr = null;
	String errorMessage = null;

	@RequestMapping(value="/login.do",method=RequestMethod.GET)
	public ModelAndView loginUser(@RequestParam(required = false) String authfailed, String logout, String denied){
		String message = "";
		if (authfailed != null) {
			message = "Invalid userid or password";
		} else if (logout != null) {
			message = "Logged Out successfully, login again to continue";
		} else if (denied != null) {
			message = "Access denied for this user !";
		}
		return new ModelAndView("login", "message", message);

		//		if(!model.containsAttribute("userDetails")){
		//			UserDetails userDetails = new UserDetails();
		//			userDetails.setUserId(loggedInUsr);
		//			model.addAttribute("userDetails", userDetails);
		//			model.addAttribute("errorMessage", errorMessage);
		//		}
		//		System.out.println("showing login page");
		//		return "login";
	}
	
	@RequestMapping("/403page")
	 public String ge403denied() {
	  return "redirect:login?denied";
	 }

	@RequestMapping(value = "/authenticate", method = RequestMethod.POST)
	public String authenticateUser(@ModelAttribute("userDetails") UserDetails userDetails, ModelMap model, HttpServletRequest request) {
		System.out.println("id: "+userDetails.getUserId()+" pwd: "+userDetails.getPassword());
		try{
			if(authenticationService.isUserAuthenticated(userDetails)){
				return "docstore";
			}
			else{
				loggedInUsr = userDetails.getUserId();
				errorMessage = "Invalid user id or password";
				return "redirect:/auth/login.do";
			}
		}
		catch(AuthenticationServiceException e){
			return handleException(request, e, model);
		}
	}

	private String handleException(HttpServletRequest request, Exception e, ModelMap modelMap){
		String message = null;
		String exceptionCode = null;
		if(e instanceof BusinessException){
			exceptionCode = ((BusinessException)e).getExceptionCode();
		}
		message = e.getMessage();
		modelMap.addAttribute("requestedUrl", request.getRequestURL());
		modelMap.addAttribute("message", message);
		modelMap.addAttribute("exceptionCode", exceptionCode);
		return "error/exception";
	}

}
