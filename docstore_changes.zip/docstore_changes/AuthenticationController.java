package com.docstore.portal.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.docstore.core.domain.UserDetails;
import com.docstore.core.exception.AuthenticationServiceException;
import com.docstore.core.exception.BusinessException;
import com.docstore.service.AuthenticationService;

@Controller
@RequestMapping(value = "/auth")
public class AuthenticationController{

	@Autowired
	AuthenticationService authenticationService;

	Integer loggedInUsr = null;
	String errorMessage = null;

	@RequestMapping(value="/login.do",method=RequestMethod.GET)
	public String loginUser(ModelMap model){
		if(!model.containsAttribute("userDetails")){
			UserDetails userDetails = new UserDetails();
			userDetails.setUserId(loggedInUsr);
			model.addAttribute("userDetails", userDetails);
			model.addAttribute("errorMessage", errorMessage);
		}
		System.out.println("showing login page");
		return "login";
	}

	@RequestMapping(value = "/authenticate", method = RequestMethod.POST)
	public String authenticateUser(@ModelAttribute("userDetails") UserDetails userDetails, ModelMap model, HttpServletRequest request) {
		System.out.println("id: "+userDetails.getUserId()+" pwd: "+userDetails.getPassword());
		try{
			UserDetails authenticatedUser = authenticationService.isUserAuthenticated(userDetails);
			if(null != request.getSession()){
				if(null != request.getSession().getAttribute("userDetails")){
					System.out.println("session exists ");
				}
			}
			if(null != authenticatedUser){
				HttpSession session = request.getSession(true);
				System.out.println("maxInactiveInterval "+session.getMaxInactiveInterval());
				Double val=Math.random();
				session.setAttribute("JSESSIONID", Double.toString(val));
				session.setAttribute("userDetails", authenticatedUser);
				return "redirect:/home";
			}
			else{
				loggedInUsr = userDetails.getUserId();
				errorMessage = "Invalid user id or password";
				return "redirect:/auth/login.do";
			}
		}
		catch(AuthenticationServiceException e){
			return handleException(request, e, model);
		}
	}
	
	@RequestMapping(value="/logout",method=RequestMethod.GET)
	public String logout(HttpServletRequest request){
		HttpSession session = request.getSession();
		session.invalidate();
//		if(!model.containsAttribute("userDetails")){
//			UserDetails userDetails = new UserDetails();
//			userDetails.setUserId(loggedInUsr);
//			model.addAttribute("userDetails", userDetails);
//			model.addAttribute("errorMessage", errorMessage);
//		}
		System.out.println("user logged out");
		return "redirect:/auth/login.do";
	}
	
	private String handleException(HttpServletRequest request, Exception e, ModelMap modelMap){
		String message = null;
		String exceptionCode = null;
		if(e instanceof BusinessException){
			exceptionCode = ((BusinessException)e).getExceptionCode();
		}
		message = e.getMessage();
		modelMap.addAttribute("requestedUrl", request.getRequestURL());
		modelMap.addAttribute("message", message);
		modelMap.addAttribute("exceptionCode", exceptionCode);
		return "error/exception";
	}

}
