package com.docstore.portal.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.docstore.core.domain.UserDetails;

@Controller
@RequestMapping(value = "/auth")
public class AuthenticationController {
	
	Integer loggedInUsr = null;
	String errorMessage = null;
	
	@RequestMapping(value="/login.do",method=RequestMethod.GET)
	public String loginUser(ModelMap model){
		if(!model.containsAttribute("userDetails")){
			UserDetails userDetails = new UserDetails();
			userDetails.setUserId(loggedInUsr);
			model.addAttribute("userDetails", userDetails);
			model.addAttribute("errorMessage", errorMessage);
		}
		System.out.println("showing login page");
		return "login";
	}
	
	@RequestMapping(value = "/authenticate", method = RequestMethod.POST)
    public String authenticateUser(@ModelAttribute("userDetails") UserDetails userDetails, ModelMap model) {
		System.out.println("id: "+userDetails.getUserId()+" pwd: "+userDetails.getPassword());
		System.out.println("authenticating");
		if(userDetails.getPassword().equals("password")){
			return "docstore";
		}
		else{
			loggedInUsr = userDetails.getUserId();
			errorMessage = "Invalid user id or password";
			return "redirect:/auth/login.do";
		}
    }

}
