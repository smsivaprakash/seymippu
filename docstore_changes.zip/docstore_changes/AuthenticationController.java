package com.docstore.portal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.docstore.core.dao.TUsrDAO;
import com.docstore.core.entity.TUsr;

@Controller
@RequestMapping(value = "/auth")
public class AuthenticationController {
	
	@Autowired
	TUsrDAO tUsrDAO;
	
	@RequestMapping(value="/login.do",method=RequestMethod.GET)
	public void loginUser(){
		System.out.println("login page");
		TUsr tUsr = tUsrDAO.findTUsrById(1001);
		System.out.println("username: "+tUsr.getUsrName());
		System.out.println("email: "+tUsr.getEmail());
		System.out.println("pwd: "+tUsr.getPassword());
		//return "login";
	}

}
