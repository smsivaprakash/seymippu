package com.docstore.dao.service;

import com.docstore.core.domain.UserDetails;
import com.docstore.core.exception.DocstoreDataAccessException;

public interface AuthenticationDAOService {
	
	public boolean isUserAuthenticated(UserDetails userDetails) throws DocstoreDataAccessException;

}
