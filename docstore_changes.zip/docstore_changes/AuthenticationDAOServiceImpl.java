package com.docstore.dao.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.docstore.core.dao.TUsrDAO;
import com.docstore.core.domain.UserDetails;
import com.docstore.core.entity.TUsr;
import com.docstore.core.exception.DocstoreDataAccessException;

@Component
public class AuthenticationDAOServiceImpl implements AuthenticationDAOService{
	
	@Autowired
	TUsrDAO tUsrDAO;

	@Override
	public boolean isUserAuthenticated(UserDetails userDetails)
			throws DocstoreDataAccessException {
		boolean isUserAuthenticated = false;
		try{
			if(null != userDetails.getUserId()){
				TUsr tUsr = tUsrDAO.findTUsrById(userDetails.getUserId());
				if(null != tUsr && tUsr.getPassword().equals(userDetails.getPassword())){
					isUserAuthenticated = true;
				}
			}
		}
		catch(RuntimeException e){
			throw new DocstoreDataAccessException("Error while authenticating user", e);
		}
		return isUserAuthenticated;
	}

}
