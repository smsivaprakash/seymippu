package com.docstore.service;

import com.docstore.core.domain.UserDetails;
import com.docstore.core.exception.AuthenticationServiceException;

public interface AuthenticationService {
	
	public UserDetails isUserAuthenticated(UserDetails userDetails) throws AuthenticationServiceException;

}
