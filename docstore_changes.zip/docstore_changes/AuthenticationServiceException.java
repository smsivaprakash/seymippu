package com.docstore.core.exception;

public class AuthenticationServiceException extends BusinessException{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -8963572380440797138L;
	
public enum AuthenticationServiceExceptionCode {
		
		AUTH_SER_EX_CD_001("AUTH_SER_EX_CD_001");
		
		private final String code;
		
		private AuthenticationServiceExceptionCode(String code) {
			this.code = code;
		}
		public String getCode() {
		    return this.code;
		}		
	}
	
	/**
	 * 
	 * @param code
	 * @param message
	 */
	public AuthenticationServiceException(String code, String message) {
		super(code, message);
	}
	
	/**
	 * Instantiates a new customer service exception.
	 *
	 * @param exceptionCode the exception code
	 * @param exceptionContext the exception context
	 * @param args the args
	 * @param cause the cause
	 */
	public AuthenticationServiceException(AuthenticationServiceExceptionCode exceptionCode, final String exceptionContext, final Object[] args, final Throwable cause) {
		super (exceptionCode.getCode(), exceptionContext, args, cause);
	}		


}
