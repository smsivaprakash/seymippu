package com.docstore.service.authentication;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.docstore.core.domain.UserDetails;
import com.docstore.core.exception.AuthenticationServiceException;
import com.docstore.core.exception.AuthenticationServiceException.AuthenticationServiceExceptionCode;
import com.docstore.core.exception.DocstoreDataAccessException;
import com.docstore.dao.service.AuthenticationDAOService;

@Service("authenticationService")
public class AuthenticationServiceImpl implements AuthenticationService{
	
	@Autowired
	AuthenticationDAOService authenticationDAOService;

	@Override
	public boolean isUserAuthenticated(UserDetails userDetails)
			throws AuthenticationServiceException {
		try{
			return authenticationDAOService.isUserAuthenticated(userDetails);
		}
		catch(DocstoreDataAccessException e){
			throw new AuthenticationServiceException(AuthenticationServiceExceptionCode.AUTH_SER_EX_CD_001, 
					"exception while authenticating user", null, e);
		}
	}

}
