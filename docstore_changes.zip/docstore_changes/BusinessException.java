package com.docstore.core.exception;

public class BusinessException extends Exception{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 8148470083825830054L;
	
	/** Exception code. */
	private String exceptionCode = null;	

	/** Arguments for the error message *. */
	private Object[] args = null;

	/** Exception context. */
	private String exceptionContext = null;

	/**
	 * Gets the exception code.
	 *
	 * @return the exception code
	 */
	public String getExceptionCode() {
		return exceptionCode;
	}

	/**
	 * Sets the exception code.
	 *
	 * @param exceptionCode the new exception code
	 */
	public void setExceptionCode(String exceptionCode) {
		this.exceptionCode = exceptionCode;
	}

	/**
	 * Gets the args.
	 *
	 * @return the args
	 */
	public Object[] getArgs() {
		return args;
	}

	/**
	 * Sets the args.
	 *
	 * @param args the new args
	 */
	public void setArgs(Object[] args) {
		this.args = args;
	}

	/**
	 * Gets the exception context.
	 *
	 * @return the exception context
	 */
	public String getExceptionContext() {
		return exceptionContext;
	}

	/**
	 * Sets the exception context.
	 *
	 * @param exceptionContext the new exception context
	 */
	public void setExceptionContext(String exceptionContext) {
		this.exceptionContext = exceptionContext;
	}

	/**
	 * Instantiates a new business exception.
	 */
	public BusinessException() {
		super();
	}

	/**
	 * The Constructor is a convenient method to create the exception without
	 * the the throwable object. In case a new exception to be created from
	 * scratch this constructor would be used.
	 * 
	 * @param exceptionCode
	 *            This denotes any rule violation or a business rule failure
	 *            This error code format is "MOD_nnnn", for example "CU_1000".
	 * @param exceptionContext
	 *            The context in which the error occurred are provided here. For
	 *            example, "the customer id is '4567' "
	 */
	public BusinessException(final String exceptionCode,
			final String exceptionContext) {
		super();
		this.exceptionCode = exceptionCode;
		this.exceptionContext = exceptionContext;
	}

	/**
	 * The Constructor is a convenient method to create the exception with the
	 * the throwable object, from the parent exception.
	 * 
	 * @param exceptionCode
	 *            This denotes any rule violation or a business rule failure
	 *            This error code format is "MOD_nnnn", for example "CU_1000".
	 * @param exceptionContext
	 *            The context in which the error occured are provided here. For
	 *            example, "the Customer id is '4567'"
	 * @param cause
	 *            the parent exception is nested with this exception, so the
	 *            root cause is not lost
	 */
	public BusinessException(final String exceptionCode,
			final String exceptionContext, final Throwable cause) {
		this(exceptionCode, exceptionContext);
		this.initCause(cause);
	}

	/**
	 * Instantiates a new business exception.
	 *
	 * @param exceptionCode the exception code
	 * @param exceptionContext the exception context
	 * @param args the args
	 * @param cause the cause
	 */
	public BusinessException(final String exceptionCode,
			final String exceptionContext, final Object[] args,
			final Throwable cause) {
		this(exceptionCode, exceptionContext);
		this.setArgs(args);
		this.initCause(cause);
	}
	
	@Override
	public String getMessage() {
		return exceptionContext == null ? String
				.format("[%1$s]", exceptionCode) : String.format("[%1$s] %2$s",
				exceptionCode, exceptionContext);
	}

}
