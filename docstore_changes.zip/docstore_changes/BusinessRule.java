package com.docstore.core.domain;

import java.io.Serializable;

public class BusinessRule implements Serializable {

	private static final long serialVersionUID = 949061161860123760L;
	
	private String ruleName;
	
	private String ruleTarget;
	
	private String docstoreName;
	
	private Integer movementDays;

	public String getRuleName() {
		return ruleName;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	public String getRuleTarget() {
		return ruleTarget;
	}

	public void setRuleTarget(String ruleTarget) {
		this.ruleTarget = ruleTarget;
	}

	public String getDocstoreName() {
		return docstoreName;
	}

	public void setDocstoreName(String docstoreName) {
		this.docstoreName = docstoreName;
	}

	public Integer getMovementDays() {
		return movementDays;
	}

	public void setMovementDays(Integer movementDays) {
		this.movementDays = movementDays;
	}

}
