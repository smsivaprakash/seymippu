//package com.docstore.core.domain;
//
//public enum ContentType {
//	
//	TXT("text/plain"),
//	DOCX("application/msword"),
//	XLSX("application/vnd.ms-excel"),
//	ZIP("application/zip"),
//	PDF("application/pdf");
//
//	private final String contentType;
//
//	private ContentType(String contentType) {
//		this.contentType = contentType;
//	}
//	public String getCode() {
//		return this.contentType;
//	}		
//
//}
