package com.docstore.core.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class ContentTypeUtil {
	
	Map<String,String> contentTypes = null;
	
	public ContentTypeUtil(){
		contentTypes = new HashMap<String, String>();
		Properties prop = new Properties();
		InputStream inputStream;
		try {
			inputStream = new FileInputStream(System.getProperty("content.type.file"));
			prop.load(inputStream);
			Enumeration<?> e = prop.propertyNames();
			while (e.hasMoreElements()) {
				String key = (String) e.nextElement();
				String value = prop.getProperty(key);
				contentTypes.put(key, value);
			}
		} catch (FileNotFoundException e) {
			System.out.println("could not load content types form file");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("Error while reading content type file");
			e.printStackTrace();
		}
	}

	public Map<String, String> getContentTypes() {
		return contentTypes;
	}

	public void setContentTypes(Map<String, String> contentTypes) {
		this.contentTypes = contentTypes;
	}

}
