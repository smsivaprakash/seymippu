package com.docstore.portal.common;

import java.io.Serializable;

public class DeleteResponse implements Serializable{

	private static final long serialVersionUID = -3643707625483036655L;

	private Integer id;

	private boolean success = false;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}
}
