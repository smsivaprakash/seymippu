package com.docstore.core.domain;

import java.util.Date;

/**
 * The Class Docstore.
 */
public class Docstore {
	
	private Integer docstoreId;
	
	private String docstoreName;
	
	private String description;
	
	private Integer createdBy;
	
	private Date createdDate;
	
	public Integer getDocstoreId() {
		return docstoreId;
	}

	public void setDocstoreId(Integer docstoreId) {
		this.docstoreId = docstoreId;
	}

	public String getDocstoreName() {
		return docstoreName;
	}

	public void setDocstoreName(String docstoreName) {
		this.docstoreName = docstoreName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

}
