package com.docstore.portal.ajax.contoller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.docstore.core.domain.Docstore;
import com.docstore.core.domain.UserDetails;
import com.docstore.core.exception.DocstoreServiceException;
import com.docstore.portal.common.DeleteResponse;
import com.docstore.portal.common.GridResponse;
import com.docstore.portal.common.ServiceResponse;
import com.docstore.portal.common.ServiceResult;
import com.docstore.portal.common.ServiceStatus;
import com.docstore.service.DocstoreService;

@Controller
@RequestMapping(value = "/ajax")
public class DocstoreAjaxContoller {
	
	@Autowired
	DocstoreService docstoreService;

	@RequestMapping(value="/listDocstores",method=RequestMethod.GET)
	public @ResponseBody GridResponse listDocstores(ModelMap modelMap, HttpServletRequest request){
		GridResponse gridResponse = new GridResponse();
		try{
			UserDetails userDetails = (UserDetails) request.getSession().getAttribute("userDetails");
			System.out.println("in test "+userDetails.getUserName());
			List<Docstore> docstores = docstoreService.fetchDocstoresByUserId(userDetails);
			if(null != docstores && !docstores.isEmpty()){
				List<Object> docstoreList = new ArrayList<Object>(docstores);
				gridResponse.setRows(docstoreList);
				gridResponse.setRecords(String.valueOf(docstoreList.size()));
				gridResponse.setPage("1");
				gridResponse.setTotal("10");
			}
		}
		catch(DocstoreServiceException e){
			e.printStackTrace();
		}
		return gridResponse;
	}
	
	@RequestMapping(value="/listObjects",method=RequestMethod.GET)
	public @ResponseBody GridResponse listObjects(@RequestParam("docstoreName") String docstoreName, @RequestParam("prefix") String prefix, 
			ModelMap modelMap, HttpServletRequest request){
		GridResponse gridResponse = new GridResponse();
		try{
			UserDetails userDetails = (UserDetails) request.getSession().getAttribute("userDetails");
			System.out.println("in test "+userDetails.getUserName());
			List<Docstore> docstores = docstoreService.fetchDocstoresByUserId(userDetails);
			if(null != docstores && !docstores.isEmpty()){
				List<Object> docstoreList = new ArrayList<Object>(docstores);
				gridResponse.setRows(docstoreList);
				gridResponse.setRecords(String.valueOf(docstoreList.size()));
				gridResponse.setPage("1");
				gridResponse.setTotal("10");
			}
		}
		catch(DocstoreServiceException e){
			e.printStackTrace();
		}
		return gridResponse;
	}
	
	@RequestMapping(value="/deleteDocstore",method=RequestMethod.POST)
	public @ResponseBody ServiceResponse<DeleteResponse> deleteDocstore(@RequestParam("id") Integer docstoreId,
			@RequestParam("name") String docstoreName){
		System.out.println("docstore to be deleted: "+docstoreId);
		boolean isDocstoreDeleted = false;
		ServiceResponse<DeleteResponse> response = new ServiceResponse<DeleteResponse>();
		ServiceStatus serviceStatus = new ServiceStatus();
		ServiceResult<DeleteResponse> result = new ServiceResult<DeleteResponse>();
		try{
			isDocstoreDeleted = docstoreService.deleteDocstore(docstoreId, docstoreName);
			if(isDocstoreDeleted){
				serviceStatus.setStatusCode(200);
				serviceStatus.setMessage("OK");
				DeleteResponse deleteResponse = new DeleteResponse();
				deleteResponse.setId(docstoreId);
				result.setDetail(deleteResponse);
			}	
		}
		catch(DocstoreServiceException e){
			serviceStatus.setStatusCode(500);
			serviceStatus.setMessage("Internal Server Error");
		}
		response.setStatus(serviceStatus);
		response.setResult(result);
		return response;
	}
}
