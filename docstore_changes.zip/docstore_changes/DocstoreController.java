package com.docstore.portal.controller;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.docstore.core.domain.Docstore;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.docstore.portal.common.GridResponse;

@Controller
public class DocstoreController {
	
	@RequestMapping(value="/list",method=RequestMethod.GET)
	public @ResponseBody GridResponse listDocstores(){
		Docstore docstore1 = new Docstore();
		docstore1.setDocstoreId(1);
		docstore1.setDocstoreName("docstore1");
		docstore1.setDescription("description1");
		docstore1.setCreatedDate(new Date());
		
		Docstore docstore2 = new Docstore();
		docstore2.setDocstoreId(2);
		docstore2.setDocstoreName("docstore2");
		docstore2.setDescription("description2");
		docstore2.setCreatedDate(new Date());
		List<Object> docstoreList = new ArrayList<Object>();
		docstoreList.add(docstore1);
		docstoreList.add(docstore2);
		
		GridResponse gridResponse = new GridResponse();
		gridResponse.setRows(docstoreList);
		gridResponse.setRecords(String.valueOf(docstoreList.size()));
		gridResponse.setPage("1");
		gridResponse.setTotal("10");
		return gridResponse;
	}
	
	@RequestMapping(value="/create",method=RequestMethod.GET)
	public String createDocstore(){
		return "createDocstore";
	}
	
	@RequestMapping(value="/delete",method=RequestMethod.GET)
	public String deleteDocstore(){
		System.out.println("deleting...");
		return "redirect:/list";
	}

}
