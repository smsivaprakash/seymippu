package com.docstore.portal.controller;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.docstore.core.domain.AccessType;
import com.docstore.core.domain.BusinessRule;
import com.docstore.core.domain.Docstore;
import com.docstore.core.domain.Notification;
import com.docstore.core.domain.UserDetails;
import com.docstore.core.exception.BusinessException;
import com.docstore.core.exception.DocstoreServiceException;
import com.docstore.service.DocstoreService;

@Controller
public class DocstoreController{
	
	private String sourcePrefix = null;

	@Value("${docstore.fileCreatorPath:''}")
	private String fileCreatorPath;

	@Autowired
	DocstoreService docstoreService;

	//	String msg_nameNotAvailable = null;
	//	Docstore docstoreDetails = null;
	@RequestMapping(value="/home",method=RequestMethod.GET)
	public String handleDocstoreListing(HttpServletRequest request){
		UserDetails userDetails = (UserDetails) request.getSession().getAttribute("userDetails");
		if(null != userDetails){
			return "docstore";
		}
		else{
			return "redirect:/auth/login.do";
		}
	}

	@RequestMapping(value="/create",method=RequestMethod.GET)
	public String createDocstore(ModelMap model, @ModelAttribute("docstoreDetails") Docstore docstoreRedirected, HttpServletRequest request){
		System.out.println("in createDocstore...");
		UserDetails userDetails = (UserDetails) request.getSession().getAttribute("userDetails");
		if(null != userDetails){
			if(null != docstoreRedirected.getDocstoreName() && null != docstoreRedirected.getDescription()){
				System.out.println("redirected: true");
				System.out.println("name: "+docstoreRedirected.getDocstoreName()+" desc: "+docstoreRedirected.getDescription());
				model.addAttribute("errorMessage", "Docstore name not available. Please enter different name");
				model.addAttribute("docstoreDetails", docstoreRedirected);
			}
			else{
				System.out.println("redirected: false");
				model.addAttribute("errorMessage", "");
				model.addAttribute("docstoreDetails", new Docstore());
			}
			return "createDocstore";
		}
		else{
			return "redirect:/auth/login.do";
		}
	}

	@RequestMapping(value="/checkNameAvailability",method=RequestMethod.POST)
	public String checkIfDocstoreNameAvailable(@ModelAttribute("docstoreDetails") Docstore docstore, ModelMap modelMap, 
			HttpServletRequest request, RedirectAttributes attributes){
		System.out.println("docstoreName: "+docstore.getDocstoreName()+" desc: "+docstore.getDescription());
		try{
			UserDetails userDetails = (UserDetails) request.getSession().getAttribute("userDetails");
			System.out.println("createdBy: "+userDetails.getUserId());
			docstore.setCreatedBy(userDetails.getUserId());
			if(docstoreService.createDocstore(docstore)){
				return "redirect:/view?name="+docstore.getDocstoreName()+"&prefix=";
			}
			else{
				attributes.addFlashAttribute("docstoreDetails", docstore);
				return "redirect:/create";
			}
		}
		catch(DocstoreServiceException e){
			return handleException(request, e, modelMap);
		}
	}

	@RequestMapping(value="/view",method=RequestMethod.GET)
	public String viewDocstore(@RequestParam("name") String docstoreName, @RequestParam("prefix") String prefix, 
			@RequestParam("copiedFiles") String[] copiedFiles, @RequestParam("sourcePref") String sourcePref, 
			ModelMap model, HttpServletRequest request){
		System.out.println("copiedFiles length "+copiedFiles.length);
		try{
			UserDetails userDetails = (UserDetails) request.getSession().getAttribute("userDetails");
			if(null != userDetails){
				model.addAttribute("docstoreName", docstoreName);
				model.addAttribute("prefix", prefix);
				model.addAttribute("key", "");
				model.addAttribute("notificationEvents", docstoreService.findNotificationEventsByDocstore(docstoreName));
				AccessType accessType = docstoreService.getAccessType(docstoreName, userDetails);
				if(null != accessType){
					model.addAttribute("accessType", accessType.toString());
				}
				if(copiedFiles.length == 0){
					model.addAttribute("copyFlag", "false");
				}
				else{
					model.addAttribute("copyFlag", "true");
					sourcePrefix = sourcePref;
					System.out.println("sourcePrefix "+sourcePrefix);
//					StringBuffer buffer = new StringBuffer("");
//					for(String file : copiedFiles){
//						buffer.append(file);
//						buffer.append(":");
//					}
//					String fileNames = buffer.toString();
//					fileNames = fileNames.substring(0, fileNames.length()-1);
//					model.addAttribute("copiedFiles", fileNames);
					System.out.println("filesArray "+Arrays.asList(copiedFiles));
					model.addAttribute("copiedFiles", Arrays.asList(copiedFiles));
				}
				return "viewDocstore";
			}
			else{
				return "redirect:/auth/login.do";
			}
		}
		catch(DocstoreServiceException e){
			return handleException(request, e, model);
		}
	}

	@RequestMapping(value="/listVersions",method=RequestMethod.GET)
	public String listVersions(@RequestParam("name") String docstoreName, @RequestParam("prefix") String prefix, 
			@RequestParam("key") String key, ModelMap model, HttpServletRequest request){
		try{
			UserDetails userDetails = (UserDetails) request.getSession().getAttribute("userDetails");
			if(null != userDetails){
				model.addAttribute("docstoreName", docstoreName);
				model.addAttribute("prefix", prefix);
				model.addAttribute("key", key);
				model.addAttribute("notificationEvents", docstoreService.findNotificationEventsByDocstore(docstoreName));
				model.addAttribute("copyFlag", "false");
				AccessType accessType = docstoreService.getAccessType(docstoreName, userDetails);
				if(null != accessType){
					model.addAttribute("accessType", accessType.toString());
				}
				return "viewDocstore";
			}
			else{
				return "redirect:/auth/login.do";
			}
		}
		catch(DocstoreServiceException e){
			return handleException(request, e, model);
		}
	}

	@RequestMapping(value="/uploadFile",method=RequestMethod.POST)
	public String uploadFile(@RequestParam("file") MultipartFile multipartFile, @RequestParam("name") String docstoreName,
			@RequestParam("prefix") String prefix, ModelMap model, HttpServletRequest request){
		InputStream inputStream = null;
		try{
			UserDetails userDetails = (UserDetails) request.getSession().getAttribute("userDetails");
			if(null != userDetails){
				if(null != multipartFile && null != docstoreName && null != prefix){
					System.out.println("multipartfilename "+multipartFile.getOriginalFilename());
					inputStream = multipartFile.getInputStream();
					long fileSize = multipartFile.getSize();
					String uploadDirectory = null;
					if("".equals(prefix.trim())){
						uploadDirectory = docstoreName;
					}
					else{
						uploadDirectory = docstoreName + "/" + prefix;
					}
					if(docstoreService.uploadObject(uploadDirectory, multipartFile.getOriginalFilename(), inputStream, fileSize)){
						model.addAttribute("successMessage", "The file "+multipartFile.getOriginalFilename()+" uploaded successfully");
						inputStream.close();
						String[] notificationEvents = docstoreService.findNotificationEventsByDocstore(docstoreName).split(",");
						for(String event : notificationEvents){
							if(event.equals("1")){
								Notification notification = new Notification();
								notification.setDocstoreName(docstoreName);
								notification.setNotificationEvent("create");
								notification.setSource(uploadDirectory+"/"+multipartFile.getOriginalFilename());
								docstoreService.sendMail(notification, userDetails);
								break;
							}
						}
					}
					else{
						model.addAttribute("errorMessage", "Failed to upload the file "+multipartFile.getOriginalFilename());
					}
					model.addAttribute("docstoreName", docstoreName);
					model.addAttribute("prefix", prefix);
					model.addAttribute("notificationEvents", docstoreService.findNotificationEventsByDocstore(docstoreName));
					model.addAttribute("copyFlag", "false");
					AccessType accessType = docstoreService.getAccessType(docstoreName, userDetails);
					if(null != accessType){
						model.addAttribute("accessType", accessType.toString());
					}
				}
				return "viewDocstore";
			}
			else{
				return "redirect:/auth/login.do";
			}
		}
		catch(DocstoreServiceException e){
			return handleException(request, e, model);
		} catch (IOException e) {
			return handleException(request, e, model);
		}
	}

	@RequestMapping(value="/createFolder",method=RequestMethod.POST)
	public String createFolder(@RequestParam("name") String docstoreName, @RequestParam("folderName") String folderName, 
			@RequestParam("prefix") String prefix, ModelMap model, HttpServletRequest request){
		try{
			UserDetails userDetails = (UserDetails) request.getSession().getAttribute("userDetails");
			if(null != userDetails){
				System.out.println("fldrNm: "+folderName+" prefix: "+prefix+" docstrNm: "+docstoreName);
				if(docstoreService.createFolder(docstoreName, prefix, folderName)){
					model.addAttribute("successMessage", "The folder \""+folderName+"\" has been created successfully");
				}
				else{
					model.addAttribute("errorMessage", "Error while creating folder \""+folderName+"\"");
				}
				model.addAttribute("docstoreName", docstoreName);
				model.addAttribute("prefix", prefix);
				model.addAttribute("notificationEvents", docstoreService.findNotificationEventsByDocstore(docstoreName));
				model.addAttribute("copyFlag", "false");
				AccessType accessType = docstoreService.getAccessType(docstoreName, userDetails);
				if(null != accessType){
					model.addAttribute("accessType", accessType.toString());
				}
				return "viewDocstore";
			}
			else{
				return "redirect:/auth/login.do";
			}	
		}
		catch(DocstoreServiceException e){
			return handleException(request, e, model);
		}
	}

	@RequestMapping(value="/businessRules",method=RequestMethod.GET)
	public String viewBusinessRules(@RequestParam("name") String docstoreName, ModelMap model, HttpServletRequest request){
		System.out.println("in businessRules...");
		model.addAttribute("docstoreName", docstoreName);
		model.addAttribute("businessRule", new BusinessRule());
		return "businessRules";
	}

	@RequestMapping(value="/addRule",method=RequestMethod.POST)
	public String addBusinessRule(@ModelAttribute("businessRule") BusinessRule businessRule, ModelMap model, HttpServletRequest request){
		System.out.println("adding business rule...");
		System.out.println("ruleName "+businessRule.getRuleName());
		System.out.println("ruletarget "+businessRule.getRuleTarget());
		System.out.println("days "+businessRule.getMovementDays());
		System.out.println("docstoreName "+businessRule.getDocstoreName());
		try{
			if(!docstoreService.addBusinessRule(businessRule)){
				model.addAttribute("errorMessage", "Error occured while adding business rule: "+businessRule.getRuleName()+" to the docstore");
			}
			model.addAttribute("docstoreName", businessRule.getDocstoreName());
			model.addAttribute("businessRule", new BusinessRule());
			return "businessRules";
		}
		catch(DocstoreServiceException e){
			return handleException(request, e, model);
		}
	}

	@RequestMapping(value="/editRule",method=RequestMethod.POST)
	public String editBusinessRule(@ModelAttribute("businessRule") BusinessRule businessRule, 
			@RequestParam("existingRule") String existingRule, ModelMap model, HttpServletRequest request){
		System.out.println("editing business rule...");
		System.out.println("existingRule "+existingRule);
		System.out.println("ruleName "+businessRule.getRuleName());
		System.out.println("ruletarget "+businessRule.getRuleTarget());
		System.out.println("days "+businessRule.getMovementDays());
		System.out.println("docstoreName "+businessRule.getDocstoreName());
		try{
			if(!docstoreService.editBusinessRule(businessRule, existingRule)){
				model.addAttribute("errorMessage", "Error occured while editing business rule: "+businessRule.getRuleName());
			}
			model.addAttribute("docstoreName", businessRule.getDocstoreName());
			model.addAttribute("businessRule", new BusinessRule());
			return "businessRules";
		}
		catch(DocstoreServiceException e){
			return handleException(request, e, model);
		}
	}

	@RequestMapping(value="/deleteRule",method=RequestMethod.GET)
	public String deleteBusinessRule(@RequestParam("name") String docstoreName, @RequestParam("ruleName") String ruleName, 
			ModelMap model, HttpServletRequest request){
		System.out.println("deleting business rule...");
		System.out.println("ruleName "+ruleName);
		System.out.println("docstoreName "+docstoreName);
		try{
			if(!docstoreService.deleteBusinessRule(ruleName, docstoreName)){
				model.addAttribute("errorMessage", "Error occured while deleting business rule: "+ruleName);
			}
			model.addAttribute("docstoreName", docstoreName);
			model.addAttribute("businessRule", new BusinessRule());
			return "businessRules";
		}
		catch(DocstoreServiceException e){
			return handleException(request, e, model);
		}
	}

	@RequestMapping(value="/createFile",method=RequestMethod.GET)
	public String createFile(@RequestParam("name") String docstoreName, @RequestParam("prefix") String prefix, 
			@RequestParam("fileName") String fileName, ModelMap model, HttpServletRequest request){
		InputStream inputStream = null;
		try{
			UserDetails userDetails = (UserDetails) request.getSession().getAttribute("userDetails");
			if(null != userDetails){
				if(null != fileName && null != docstoreName && null != prefix){
					System.out.println("fileName "+fileName);
					File file = new File(fileCreatorPath+"\\"+fileName);
					inputStream = new FileInputStream(file);
					long fileSize = file.length();
					String uploadDirectory = null;
					if("".equals(prefix.trim())){
						uploadDirectory = docstoreName;
					}
					else{
						uploadDirectory = docstoreName + "/" + prefix;
					}
					if(docstoreService.uploadObject(uploadDirectory, fileName, inputStream, fileSize)){
						String[] notificationEvents = docstoreService.findNotificationEventsByDocstore(docstoreName).split(",");
						for(String event : notificationEvents){
							if(event.equals("1")){
								Notification notification = new Notification();
								notification.setDocstoreName(docstoreName);
								notification.setNotificationEvent("create");
								notification.setSource(uploadDirectory+"/"+fileName);
								docstoreService.sendMail(notification, userDetails);
								break;
							}
						}
					}
					else{
						model.addAttribute("errorMessage", "Failed to create file "+fileName);
					}
					inputStream.close();
					model.addAttribute("docstoreName", docstoreName);
					model.addAttribute("prefix", prefix);
					model.addAttribute("notificationEvents", docstoreService.findNotificationEventsByDocstore(docstoreName));
					model.addAttribute("copyFlag", "false");
					AccessType accessType = docstoreService.getAccessType(docstoreName, userDetails);
					if(null != accessType){
						model.addAttribute("accessType", accessType.toString());
					}
				}
				return "viewDocstore";
			}
			else{
				return "redirect:/auth/login.do";
			}
		}
		catch(DocstoreServiceException e){
			return handleException(request, e, model);
		} catch (IOException e) {
			return handleException(request, e, model);
		}
	}

	@RequestMapping(value="/notificationEvents",method=RequestMethod.GET)
	public String notificationEvents(@RequestParam("name") String docstoreName, @RequestParam("prefix") String prefix, 
			@RequestParam("notificationsName") String notificationsName, @RequestParam("events") String[] events, 
			ModelMap model, HttpServletRequest request){
		System.out.println("notificationsName "+notificationsName);
		System.out.println("events "+events);
		try{
			UserDetails userDetails = (UserDetails) request.getSession().getAttribute("userDetails");
			if(null != userDetails){
				if(null != notificationsName && null != docstoreName && null != events){
					docstoreService.updateNotifications(docstoreName, notificationsName, events);
					model.addAttribute("notificationEvents", docstoreService.findNotificationEventsByDocstore(docstoreName));
					model.addAttribute("docstoreName", docstoreName);
					model.addAttribute("prefix", prefix);
					model.addAttribute("copyFlag", "false");
					AccessType accessType = docstoreService.getAccessType(docstoreName, userDetails);
					if(null != accessType){
						model.addAttribute("accessType", accessType.toString());
					}
				}
				return "viewDocstore";
			}
			else{
				return "redirect:/auth/login.do";
			}
		}
		catch(DocstoreServiceException e){
			return handleException(request, e, model);
		}
	}

	@RequestMapping(value="/deleteFiles",method=RequestMethod.GET)
	public String deleteFiles(@RequestParam("name") String docstoreName, @RequestParam("prefix") String prefix, 
			@RequestParam("deleteKeys") String[] deleteKeys, ModelMap model, HttpServletRequest request){
		try{
			for(String key : deleteKeys){
				System.out.println("deletekey "+key);
			}
			UserDetails userDetails = (UserDetails) request.getSession().getAttribute("userDetails");
			if(null != userDetails){
				if(docstoreService.deleteFiles(docstoreName, prefix, deleteKeys)){
					String[] notificationEvents = docstoreService.findNotificationEventsByDocstore(docstoreName).split(",");
					for(String event : notificationEvents){
						if(event.equals("2")){
							Notification notification = new Notification();
							notification.setDocstoreName(docstoreName);
							notification.setNotificationEvent("delete");
							String source = null;
							if(!"".equals(prefix.trim())){
								source = docstoreName + "/" + prefix;
							}
							notification.setSource(source);
							notification.setFileList(Arrays.asList(deleteKeys));
							docstoreService.sendMail(notification, userDetails);
							break;
						}
					}
				}
				model.addAttribute("notificationEvents", docstoreService.findNotificationEventsByDocstore(docstoreName));
				model.addAttribute("docstoreName", docstoreName);
				model.addAttribute("prefix", prefix);
				model.addAttribute("copyFlag", "false");
				AccessType accessType = docstoreService.getAccessType(docstoreName, userDetails);
				if(null != accessType){
					model.addAttribute("accessType", accessType.toString());
				}
			}
			return "viewDocstore";
		}
		catch(DocstoreServiceException e){
			return handleException(request, e, model);
		}
	}
	
	@RequestMapping(value="/paste",method=RequestMethod.GET)
	public String paste(@RequestParam("name") String docstoreName, @RequestParam("prefix") String prefix, 
			@RequestParam("copiedFiles") String[] copiedFiles, ModelMap model, HttpServletRequest request){
		String source = null;
		String destination = null;
		for(String key : copiedFiles){
			if("".equals(sourcePrefix.trim())){
				source = key;
			}
			else{
				source = sourcePrefix + "/" + key;
			}
			if("".equals(prefix.trim())){
				destination = key;
			}
			else{
				destination = prefix + "/" + key;
			}
			System.out.println("source: "+source+"   destination:"+destination);
		}
//		try{			
//			UserDetails userDetails = (UserDetails) request.getSession().getAttribute("userDetails");
//			if(null != userDetails){
//				if(docstoreService.deleteFiles(docstoreName, prefix, deleteKeys)){
//					String[] notificationEvents = docstoreService.findNotificationEventsByDocstore(docstoreName).split(",");
//					for(String event : notificationEvents){
//						if(event.equals("2")){
//							Notification notification = new Notification();
//							notification.setDocstoreName(docstoreName);
//							notification.setNotificationEvent("delete");
//							String source = null;
//							if(!"".equals(prefix.trim())){
//								source = docstoreName + "/" + prefix;
//							}
//							notification.setSource(source);
//							notification.setFileList(Arrays.asList(deleteKeys));
//							docstoreService.sendMail(notification, userDetails);
//							break;
//						}
//					}
//				}
//				model.addAttribute("notificationEvents", docstoreService.findNotificationEventsByDocstore(docstoreName));
//				model.addAttribute("docstoreName", docstoreName);
//				model.addAttribute("prefix", prefix);
//				model.addAttribute("copyFlag", "false");
//				AccessType accessType = docstoreService.getAccessType(docstoreName, userDetails);
//				if(null != accessType){
//					model.addAttribute("accessType", accessType.toString());
//				}
//			}
//			return "viewDocstore";
//		}
//		catch(DocstoreServiceException e){
//			return handleException(request, e, model);
//		}
		return "viewDocstore";
	}

	@RequestMapping(value="/createFileTester",method=RequestMethod.GET)
	public String createFile(ModelMap model, HttpServletRequest request){
		return "createFile";
	}

	private String handleException(HttpServletRequest request, Exception e, ModelMap modelMap){
		String message = null;
		String exceptionCode = null;
		if(e instanceof BusinessException){
			exceptionCode = ((BusinessException)e).getExceptionCode();
		}
		message = e.getMessage();
		modelMap.addAttribute("requestedUrl", request.getRequestURL());
		modelMap.addAttribute("message", message);
		modelMap.addAttribute("exceptionCode", exceptionCode);
		return "error/exception";
	}

}
