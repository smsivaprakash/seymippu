package com.docstore.portal.controller;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.docstore.core.domain.Docstore;
import com.docstore.core.domain.UserDetails;
import com.docstore.core.exception.BusinessException;
import com.docstore.core.exception.DocstoreServiceException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.docstore.portal.common.GridResponse;
import com.docstore.service.DocstoreService;

@Controller
public class DocstoreController{

	@Autowired
	DocstoreService docstoreService;

//	String msg_nameNotAvailable = null;
//	Docstore docstoreDetails = null;

	@RequestMapping(value="/list",method=RequestMethod.GET)
	public @ResponseBody GridResponse listDocstores(){
		Docstore docstore1 = new Docstore();
		docstore1.setDocstoreId(1);
		docstore1.setDocstoreName("docstore1");
		docstore1.setDescription("description1");
		docstore1.setCreatedDate(new Date());

		Docstore docstore2 = new Docstore();
		docstore2.setDocstoreId(2);
		docstore2.setDocstoreName("docstore2");
		docstore2.setDescription("description2");
		docstore2.setCreatedDate(new Date());
		List<Object> docstoreList = new ArrayList<Object>();
		docstoreList.add(docstore1);
		docstoreList.add(docstore2);

		GridResponse gridResponse = new GridResponse();
		gridResponse.setRows(docstoreList);
		gridResponse.setRecords(String.valueOf(docstoreList.size()));
		gridResponse.setPage("1");
		gridResponse.setTotal("10");
		return gridResponse;
	}

	@RequestMapping(value="/create",method=RequestMethod.GET)
	public String createDocstore(ModelMap model, HttpServletRequest request){
		if(null != request.getAttribute("docstoreDetails") && null != request.getAttribute("errorMessage")){
			model.addAttribute("errorMessage", request.getAttribute("errorMessage"));
			model.addAttribute("docstoreDetails", request.getAttribute("docstoreDetails"));
		}
		else{
			model.addAttribute("errorMessage", "");
			model.addAttribute("docstoreDetails", new Docstore());
		}
		return "createDocstore";
	}

	@RequestMapping(value="/checkNameAvailability",method=RequestMethod.POST)
	public String checkIfDocstoreNameAvailable(@ModelAttribute("docstoreDetails") Docstore docstore, ModelMap modelMap, 
			HttpServletRequest request, RedirectAttributes attributes){
		System.out.println("docstoreName: "+docstore.getDocstoreName()+" desc: "+docstore.getDescription());
		try{
			UserDetails userDetails = (UserDetails) request.getSession().getAttribute("userDetails");
			System.out.println("createdBy: "+userDetails.getUserId());
			docstore.setDocstoreId(null);
			docstore.setCreatedDate(new Date());
			docstore.setCreatedBy(userDetails.getUserId());
			if(docstoreService.createDocstore(docstore)){
				return "redirect:/view?name="+docstore.getDocstoreName();
			}
			else{
				attributes.addFlashAttribute("docstoreDetails", docstore);
				attributes.addFlashAttribute("errorMessage", "Docstore name not available. Please enter different name");
				return "redirect:/create";
			}
		}
		catch(DocstoreServiceException e){
			e.printStackTrace();
			return handleException(request, e, modelMap);
		}
	}

	@RequestMapping(value="/delete",method=RequestMethod.GET)
	public String deleteDocstore(){
		System.out.println("deleting...");
		return "redirect:/list";
	}

	@RequestMapping(value="/view",method=RequestMethod.GET)
	public String viewDocstore(@RequestParam("name") String docstoreName, ModelMap model, HttpServletRequest request){
		//TODO get docstore details from DB
		return "viewDocstore";
	}
	
	private String handleException(HttpServletRequest request, Exception e, ModelMap modelMap){
		String message = null;
		String exceptionCode = null;
		if(e instanceof BusinessException){
			exceptionCode = ((BusinessException)e).getExceptionCode();
		}
		message = e.getMessage();
		modelMap.addAttribute("requestedUrl", request.getRequestURL());
		modelMap.addAttribute("message", message);
		modelMap.addAttribute("exceptionCode", exceptionCode);
		return "error/exception";
	}

}
