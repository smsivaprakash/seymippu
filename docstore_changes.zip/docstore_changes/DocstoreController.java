package com.docstore.portal.controller;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.docstore.core.domain.Docstore;
import com.docstore.core.domain.UserDetails;
import com.docstore.core.exception.BusinessException;
import com.docstore.core.exception.DocstoreServiceException;
import com.docstore.service.DocstoreService;

@Controller
public class DocstoreController{

	@Autowired
	DocstoreService docstoreService;

	//	String msg_nameNotAvailable = null;
	//	Docstore docstoreDetails = null;
	@RequestMapping(value="/home",method=RequestMethod.GET)
	public String handleDocstoreListing(HttpServletRequest request){
		UserDetails userDetails = (UserDetails) request.getSession().getAttribute("userDetails");
		if(null != userDetails){
			return "docstore";
		}
		else{
			return "redirect:/auth/login.do";
		}
	}

	@RequestMapping(value="/create",method=RequestMethod.GET)
	public String createDocstore(ModelMap model, @ModelAttribute("docstoreDetails") Docstore docstoreRedirected, HttpServletRequest request){
		System.out.println("in createDocstore...");
		UserDetails userDetails = (UserDetails) request.getSession().getAttribute("userDetails");
		if(null != userDetails){
			if(null != docstoreRedirected.getDocstoreName() && null != docstoreRedirected.getDescription()){
				System.out.println("redirected: true");
				System.out.println("name: "+docstoreRedirected.getDocstoreName()+" desc: "+docstoreRedirected.getDescription());
				model.addAttribute("errorMessage", "Docstore name not available. Please enter different name");
				model.addAttribute("docstoreDetails", docstoreRedirected);
			}
			else{
				System.out.println("redirected: false");
				model.addAttribute("errorMessage", "");
				model.addAttribute("docstoreDetails", new Docstore());
			}
			return "createDocstore";
		}
		else{
			return "redirect:/auth/login.do";
		}
	}

	@RequestMapping(value="/checkNameAvailability",method=RequestMethod.POST)
	public String checkIfDocstoreNameAvailable(@ModelAttribute("docstoreDetails") Docstore docstore, ModelMap modelMap, 
			HttpServletRequest request, RedirectAttributes attributes){
		System.out.println("docstoreName: "+docstore.getDocstoreName()+" desc: "+docstore.getDescription());
		try{
			UserDetails userDetails = (UserDetails) request.getSession().getAttribute("userDetails");
			System.out.println("createdBy: "+userDetails.getUserId());
			docstore.setCreatedBy(userDetails.getUserId());
			if(docstoreService.createDocstore(docstore)){
				return "redirect:/view?name="+docstore.getDocstoreName()+"&prefix=";
			}
			else{
				attributes.addFlashAttribute("docstoreDetails", docstore);
				return "redirect:/create";
			}
		}
		catch(DocstoreServiceException e){
			return handleException(request, e, modelMap);
		}
	}

	@RequestMapping(value="/view",method=RequestMethod.GET)
	public String viewDocstore(@RequestParam("name") String docstoreName, @RequestParam("prefix") String prefix, ModelMap model, 
			HttpServletRequest request){
		UserDetails userDetails = (UserDetails) request.getSession().getAttribute("userDetails");
		if(null != userDetails){
			model.addAttribute("docstoreName", docstoreName);
			model.addAttribute("prefix", prefix);
			model.addAttribute("key", "");
			return "viewDocstore";
		}
		else{
			return "redirect:/auth/login.do";
		}
	}
	
	@RequestMapping(value="/listVersions",method=RequestMethod.GET)
	public String listVersions(@RequestParam("name") String docstoreName, @RequestParam("prefix") String prefix, 
			@RequestParam("key") String key, ModelMap model, HttpServletRequest request){
		UserDetails userDetails = (UserDetails) request.getSession().getAttribute("userDetails");
		if(null != userDetails){
			model.addAttribute("docstoreName", docstoreName);
			model.addAttribute("prefix", prefix);
			model.addAttribute("key", key);
			return "viewDocstore";
		}
		else{
			return "redirect:/auth/login.do";
		}
	}

	@RequestMapping(value="/uploadFile",method=RequestMethod.POST)
	public String uploadFile(@RequestParam("file") MultipartFile multipartFile, @RequestParam("name") String docstoreName,
			@RequestParam("prefix") String prefix, ModelMap model, HttpServletRequest request){
		InputStream inputStream = null;
		try{
			UserDetails userDetails = (UserDetails) request.getSession().getAttribute("userDetails");
			if(null != userDetails){
				if(null != multipartFile && null != docstoreName && null != prefix){
					System.out.println("multipartfilename "+multipartFile.getOriginalFilename());
					inputStream = multipartFile.getInputStream();
					long fileSize = multipartFile.getSize();
					String uploadDirectory = null;
					if("".equals(prefix.trim())){
						uploadDirectory = docstoreName;
					}
					else{
						uploadDirectory = docstoreName + "/" + prefix;
					}
					if(docstoreService.uploadObject(uploadDirectory, multipartFile.getOriginalFilename(), inputStream, fileSize)){
						model.addAttribute("successMessage", "The file "+multipartFile.getOriginalFilename()+" uploaded successfully");
						inputStream.close();
					}
					else{
						model.addAttribute("errorMessage", "Failed to upload the file "+multipartFile.getOriginalFilename());
					}
					model.addAttribute("docstoreName", docstoreName);
					model.addAttribute("prefix", prefix);
				}
				return "viewDocstore";
			}
			else{
				return "redirect:/auth/login.do";
			}
		}
		catch(DocstoreServiceException e){
			return handleException(request, e, model);
		} catch (IOException e) {
			return handleException(request, e, model);
		}
	}
	
	@RequestMapping(value="/createFolder",method=RequestMethod.POST)
	public String createFolder(@RequestParam("name") String docstoreName, @RequestParam("folderName") String folderName, 
			@RequestParam("prefix") String prefix, ModelMap model, HttpServletRequest request){
		try{
			UserDetails userDetails = (UserDetails) request.getSession().getAttribute("userDetails");
			if(null != userDetails){
				System.out.println("fldrNm: "+folderName+" prefix: "+prefix+" docstrNm: "+docstoreName);
				if(docstoreService.createFolder(docstoreName, prefix, folderName)){
					model.addAttribute("successMessage", "The folder \""+folderName+"\" has been created successfully");
				}
				else{
					model.addAttribute("errorMessage", "Error while creating folder \""+folderName+"\"");
				}
				model.addAttribute("docstoreName", docstoreName);
				model.addAttribute("prefix", prefix);
				return "viewDocstore";
			}
			else{
				return "redirect:/auth/login.do";
			}	
		}
		catch(DocstoreServiceException e){
			return handleException(request, e, model);
		}
	}

	private String handleException(HttpServletRequest request, Exception e, ModelMap modelMap){
		String message = null;
		String exceptionCode = null;
		if(e instanceof BusinessException){
			exceptionCode = ((BusinessException)e).getExceptionCode();
		}
		message = e.getMessage();
		modelMap.addAttribute("requestedUrl", request.getRequestURL());
		modelMap.addAttribute("message", message);
		modelMap.addAttribute("exceptionCode", exceptionCode);
		return "error/exception";
	}

}
