package com.docstore.portal.controller;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.docstore.core.domain.Docstore;
import com.docstore.core.domain.UserDetails;
import com.docstore.core.exception.BusinessException;
import com.docstore.core.exception.DocstoreServiceException;
import com.docstore.service.DocstoreService;

@Controller
public class DocstoreController{

	@Autowired
	DocstoreService docstoreService;

//	String msg_nameNotAvailable = null;
//	Docstore docstoreDetails = null;
	
	@RequestMapping(value="/home",method=RequestMethod.GET)
	public String handleDocstoreListing(){
		return "docstore";
	}
	
	@RequestMapping(value="/create",method=RequestMethod.GET)
	public String createDocstore(ModelMap model, @ModelAttribute("docstoreDetails") Docstore docstoreRedirected, HttpServletRequest request){
		System.out.println("in createDocstore...");
		if(null != docstoreRedirected.getDocstoreName() && null != docstoreRedirected.getDescription()){
			System.out.println("redirected: true");
			System.out.println("name: "+docstoreRedirected.getDocstoreName()+" desc: "+docstoreRedirected.getDescription());
			model.addAttribute("errorMessage", "Docstore name not available. Please enter different name");
			model.addAttribute("docstoreDetails", docstoreRedirected);
		}
		else{
			System.out.println("redirected: false");
			model.addAttribute("errorMessage", "");
			model.addAttribute("docstoreDetails", new Docstore());
		}
		return "createDocstore";
	}

	@RequestMapping(value="/checkNameAvailability",method=RequestMethod.POST)
	public String checkIfDocstoreNameAvailable(@ModelAttribute("docstoreDetails") Docstore docstore, ModelMap modelMap, 
			HttpServletRequest request, RedirectAttributes attributes){
		System.out.println("docstoreName: "+docstore.getDocstoreName()+" desc: "+docstore.getDescription());
		try{
			UserDetails userDetails = (UserDetails) request.getSession().getAttribute("userDetails");
			System.out.println("createdBy: "+userDetails.getUserId());
			docstore.setCreatedDate(new Date());
			docstore.setCreatedBy(userDetails.getUserId());
			if(docstoreService.createDocstore(docstore)){
				return "redirect:/view?name="+docstore.getDocstoreName();
			}
			else{
				attributes.addFlashAttribute("docstoreDetails", docstore);
				return "redirect:/create";
			}
		}
		catch(DocstoreServiceException e){
			return handleException(request, e, modelMap);
		}
	}

	@RequestMapping(value="/delete",method=RequestMethod.GET)
	public String deleteDocstore(){
		System.out.println("deleting...");
		return "redirect:/list";
	}

	@RequestMapping(value="/view",method=RequestMethod.GET)
	public String viewDocstore(@RequestParam("name") String docstoreName, ModelMap model, HttpServletRequest request){
		//TODO get docstore details from DB
		return "viewDocstore";
	}
	
	private String handleException(HttpServletRequest request, Exception e, ModelMap modelMap){
		String message = null;
		String exceptionCode = null;
		if(e instanceof BusinessException){
			exceptionCode = ((BusinessException)e).getExceptionCode();
		}
		message = e.getMessage();
		modelMap.addAttribute("requestedUrl", request.getRequestURL());
		modelMap.addAttribute("message", message);
		modelMap.addAttribute("exceptionCode", exceptionCode);
		return "error/exception";
	}

}
