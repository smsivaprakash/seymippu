package com.docstore.dao.service;

import java.util.List;

import com.docstore.core.domain.AccessPermission;
import com.docstore.core.domain.Docstore;
import com.docstore.core.domain.UserDetails;
import com.docstore.core.exception.DocstoreDataAccessException;

public interface DocstoreDAOService {
	
	public Docstore createDocstore(Docstore docstore) throws DocstoreDataAccessException;
	
	public List<Docstore> fetchDocstoresByUserId(UserDetails userDetails) throws DocstoreDataAccessException;
	
	public boolean deleteDocstore(Integer docstoreId) throws DocstoreDataAccessException;
	
	public Docstore fetchDocstore(Integer docstoreId) throws DocstoreDataAccessException;
	
	public void createAccessPermission(AccessPermission accessPermission) throws DocstoreDataAccessException;

}
