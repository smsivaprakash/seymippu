package com.docstore.dao.service;

import com.docstore.core.domain.Docstore;
import com.docstore.core.exception.DocstoreDataAccessException;

public interface DocstoreDAOService {
	
	public Docstore createDocstore(Docstore docstore) throws DocstoreDataAccessException;

}
