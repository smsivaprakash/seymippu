package com.docstore.dao.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.docstore.core.dao.TDocstoreDAO;
import com.docstore.core.domain.Docstore;
import com.docstore.core.domain.UserDetails;
import com.docstore.core.entity.TDocstore;
import com.docstore.core.exception.DocstoreDataAccessException;
import com.docstore.service.assembler.DocstoreEntityAssembler;
import com.docstore.service.assembler.DocstoreModelAssembler;

@Component
public class DocstoreDAOServiceImpl implements DocstoreDAOService{
	
	@Autowired
	TDocstoreDAO tDocstoreDAO;
	
	@Autowired
	DocstoreEntityAssembler docstoreEntityAssembler;
	
	@Autowired
	DocstoreModelAssembler docstoreModelAssembler;

	public Docstore createDocstore(Docstore docstore) throws DocstoreDataAccessException {
		Docstore persistedDocstore = null;
		try{
			if(null != docstore){
				TDocstore tDocstore = tDocstoreDAO.createTDocstore(docstoreEntityAssembler.mapDocstoreModelToEntity(docstore));
				if(null != tDocstore){
					persistedDocstore = docstoreModelAssembler.mapDocstoreEntityToModel(tDocstore);
				}
			}
		}
		catch(RuntimeException e){
			throw new DocstoreDataAccessException("error while creating docstore", e);
		}
		return persistedDocstore;
	}

	public List<Docstore> fetchDocstoresByUserId(UserDetails userDetails)
			throws DocstoreDataAccessException {
		List<Docstore> docstores = null;
		try{
			if(null != userDetails && null != userDetails.getUserId()){
				List<TDocstore> tDocstores = tDocstoreDAO.fetchDocstoresByUserId(userDetails.getUserId());
				if(null != tDocstores && !tDocstores.isEmpty()){
					docstores = new ArrayList<Docstore>();
					for(TDocstore tDocstore : tDocstores){
						docstores.add(docstoreModelAssembler.mapDocstoreEntityToModel(tDocstore));
					}
				}
			}
		}
		catch(RuntimeException e){
			throw new DocstoreDataAccessException("error while fetching docstores based on userId", e);
		}
		return docstores;
	}

}
