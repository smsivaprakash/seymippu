package com.docstore.dao.service;

import java.util.ArrayList;
import java.util.List;

import javax.mail.Address;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.docstore.core.dao.TAccessPermissionDAO;
import com.docstore.core.dao.TDocstoreDAO;
import com.docstore.core.dao.TNotificationDAO;
import com.docstore.core.domain.AccessPermission;
import com.docstore.core.domain.AccessType;
import com.docstore.core.domain.Docstore;
import com.docstore.core.domain.UserDetails;
import com.docstore.core.entity.TAccessPermission;
import com.docstore.core.entity.TAccessPermissionId;
import com.docstore.core.entity.TDocstore;
import com.docstore.core.entity.TEvent;
import com.docstore.core.entity.TNotification;
import com.docstore.core.exception.DocstoreDataAccessException;
import com.docstore.service.assembler.AccessPermissionEntityAssembler;
import com.docstore.service.assembler.DocstoreEntityAssembler;
import com.docstore.service.assembler.DocstoreModelAssembler;

@Component
public class DocstoreDAOServiceImpl implements DocstoreDAOService{
	
	@Autowired
	TDocstoreDAO tDocstoreDAO;
	
	@Autowired
	TAccessPermissionDAO tAccessPermissionDAO;
	
	@Autowired
	TNotificationDAO tNotificationDAO;
	
	@Autowired
	DocstoreEntityAssembler docstoreEntityAssembler;
	
	@Autowired
	DocstoreModelAssembler docstoreModelAssembler;
	
	@Autowired
	AccessPermissionEntityAssembler accessPermissionEntityAssembler;

	public Docstore createDocstore(Docstore docstore) throws DocstoreDataAccessException {
		Docstore persistedDocstore = null;
		try{
			if(null != docstore){
				TDocstore tDocstore = tDocstoreDAO.createTDocstore(docstoreEntityAssembler.mapDocstoreModelToEntity(docstore));
				if(null != tDocstore){
					persistedDocstore = docstoreModelAssembler.mapDocstoreEntityToModel(tDocstore);
				}
			}
		}
		catch(RuntimeException e){
			throw new DocstoreDataAccessException("error while creating docstore", e);
		}
		return persistedDocstore;
	}

	public List<Docstore> fetchDocstoresByUserId(UserDetails userDetails)
			throws DocstoreDataAccessException {
		List<Docstore> docstores = null;
		try{
			if(null != userDetails && null != userDetails.getUserId()){
				List<TDocstore> tDocstores = tDocstoreDAO.fetchDocstoresByUserId(userDetails.getUserId());
				if(null != tDocstores && !tDocstores.isEmpty()){
					docstores = new ArrayList<Docstore>();
					for(TDocstore tDocstore : tDocstores){
						docstores.add(docstoreModelAssembler.mapDocstoreEntityToModel(tDocstore));
					}
				}
			}
		}
		catch(RuntimeException e){
			throw new DocstoreDataAccessException("error while fetching docstores based on userId", e);
		}
		return docstores;
	}

	public boolean deleteDocstore(Integer docstoreId) throws DocstoreDataAccessException {
		boolean isDocstoreDeleted = true;
		try{
			tDocstoreDAO.deleteTDocstore(docstoreId);
			if(null != fetchDocstore(docstoreId)){
				isDocstoreDeleted = false;
			}
		}
		catch(RuntimeException e){
			throw new DocstoreDataAccessException("error while deleting docstore", e);
		}
		return isDocstoreDeleted;
	}

	public Docstore fetchDocstore(Integer docstoreId) throws DocstoreDataAccessException {
		Docstore docstore = null;
		try{
			docstore = docstoreModelAssembler.mapDocstoreEntityToModel(tDocstoreDAO.findTDocstoreById(docstoreId));
		}
		catch(RuntimeException e){
			throw new DocstoreDataAccessException("error while fetching docstore", e);
		}
		return docstore;
	}
	
	public void createAccessPermission(AccessPermission accessPermission) throws DocstoreDataAccessException {
		try{
			if(null != accessPermission){
				TAccessPermission tAccessPermission = accessPermissionEntityAssembler.mapAccessPermissionEntityToModel(accessPermission);
				tAccessPermissionDAO.createTAccessPermission(tAccessPermission);
			}
		}
		catch(RuntimeException e){
			throw new DocstoreDataAccessException("error while creating access permission", e);
		}
	}

	public AccessType getAccessType(String docstoreName, UserDetails userDetails) throws DocstoreDataAccessException {
		AccessType accessType = null;
		try{
			if(null != docstoreName && null != userDetails){
				List<Integer> tDocstores = tDocstoreDAO.fetchDocstoreIdByName(docstoreName);
				if(null != tDocstores && !tDocstores.isEmpty()){
					TAccessPermissionId tAccessPermissionId = new TAccessPermissionId();
					tAccessPermissionId.setDocstoreId(tDocstores.get(0));
					tAccessPermissionId.setUsrId(userDetails.getUserId());
					TAccessPermission tAccessPermission = tAccessPermissionDAO.findTAccessPermission(tAccessPermissionId);
					accessType =  AccessType.getAccessType(tAccessPermission.gettAccessType().getAccessTypeId());
				}
			}
		}
		catch(RuntimeException e){
			throw new DocstoreDataAccessException("error while fetching access type", e);
		}
		return accessType;
	}

	public Address[] getRecipients(String docstoreName) throws DocstoreDataAccessException {
		Address[] recipients = null;
		try{
			if(null != docstoreName){
				List<Integer> tDocstores = tDocstoreDAO.fetchDocstoreIdByName(docstoreName);
				if(null != tDocstores && !tDocstores.isEmpty()){
					List<String> recipientList = tAccessPermissionDAO.fetchEmailListByDocstoreName(tDocstores.get(0));
					if(null != recipientList && !recipientList.isEmpty()){
						recipients = new Address[recipientList.size()];
						for(int i=0;i<recipientList.size();i++){
							Address address = new InternetAddress(recipientList.get(i));
							recipients[i] = address;
						}
					}
				}
			}
		}
		catch(RuntimeException e){
			throw new DocstoreDataAccessException("error while fetching recipient list");
		} catch (AddressException e) {
			throw new DocstoreDataAccessException("error while constructing Address list");
		}
		return recipients;
	}
	
	//@Transactional
	public boolean createNotifications(String docstoreName, String notificationName, String[] event)
			throws DocstoreDataAccessException {
		boolean isNotificationCreated = false;
		try{
			List<Integer> docstoresId = tDocstoreDAO.fetchDocstoreIdByName(docstoreName);
			if(null != docstoresId && !docstoresId.isEmpty()){
				System.out.println("docstoreId "+docstoresId.get(0));
				List<TNotification> tNotifications = tNotificationDAO.findTNotificationsByDocstoreId(docstoresId.get(0));
				if(null == tNotifications || tNotifications.isEmpty()){
					System.out.println("creating notifications");
					for(String eventId : event){
						System.out.println("creating for event "+eventId);
						TNotification tNotification = new TNotification();
						tNotification.setNotificationName(notificationName);
						TDocstore tDocstore = new TDocstore();
						tDocstore.setDocstoreId(docstoresId.get(0));
						tNotification.setTDocstore(tDocstore);
						TEvent tEvent = new TEvent();
						tEvent.setEventId(Integer.valueOf(eventId));
						tNotification.setTEvent(tEvent);
						tNotification.setActiveFlag('Y');
						TNotification persistedNotification = tNotificationDAO.createTNotification(tNotification);
						if(null != persistedNotification){
							isNotificationCreated = true;
						}
					}
				}
				else{
					System.out.println("updating notifications");
					for(String eventId : event){
						Integer id = Integer.valueOf(eventId);
						for(TNotification notification : tNotifications){
							if(notification.getTEvent().getEventId() == id){
								if(notification.getActiveFlag() == 'Y'){
									//tNotifications.remove(notification);
									notification.setActiveFlag('N');
								}
								else if(notification.getActiveFlag() == 'N'){
									TNotification tNotification = notification;
									tNotification.setActiveFlag('Y');
									tNotificationDAO.updateTNotification(tNotification);
								}
							}
						}
					}
					if(!tNotifications.isEmpty()){
						for(TNotification tNotification : tNotifications){
							if(tNotification.getActiveFlag() == 'Y'){
								tNotification.setActiveFlag('N');
								tNotificationDAO.updateTNotification(tNotification);
							}
						}
					}
				}
			}
		}
		catch(RuntimeException e){
			e.printStackTrace();
			throw new DocstoreDataAccessException("error while creating notifications");
		}
		return isNotificationCreated;
	}
	
	public String findNotificationEventsByDocstore(String docstoreName) throws  DocstoreDataAccessException{
		StringBuffer events = null;
		try{
			List<Integer> docstoresId = tDocstoreDAO.fetchDocstoreIdByName(docstoreName);
			List<TNotification> tNotifications = tNotificationDAO.findTNotificationsByDocstoreId(docstoresId.get(0));
			if(null != tNotifications && !tNotifications.isEmpty()){
				String notificationName = null;
				for(TNotification notification : tNotifications){
					if(notification.getActiveFlag() == 'Y'){
						notificationName = notification.getNotificationName();
						break;
					}
				}
				events = new StringBuffer(notificationName);
				for(int i=0;i<tNotifications.size();i++){
					if(tNotifications.get(i).getActiveFlag() == 'Y'){
						events.append(",");
						events.append(tNotifications.get(i).getTEvent().getEventId());
					}
				}
			}
		}
		catch(RuntimeException e){
			e.printStackTrace();
			throw new DocstoreDataAccessException("error while fetching notifications");
		}
		return events.toString();
	}

}
