package com.docstore.core.exception;

import org.springframework.dao.DataAccessException;

public class DocstoreDataAccessException extends DataAccessException{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** The message. */
	private String message;

	/**
	 * Instantiates a new docstore data access exception.
	 *
	 * @param message the message
	 */
	public DocstoreDataAccessException(String message) {
		super(message);
		this.message = message;
	}
	
	/**
	 * Instantiates a new docstore data access exception.
	 *
	 * @param message the message
	 * @param cause the cause
	 */
	public DocstoreDataAccessException(String message, final Throwable cause) {
		super(message,cause);
	}	

	/* (non-Javadoc)
	 * @see org.springframework.core.NestedRuntimeException#getMessage()
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * Sets the message.
	 *
	 * @param message the new message
	 */
	public void setMessage(String message) {
		this.message = message;
	}

}
