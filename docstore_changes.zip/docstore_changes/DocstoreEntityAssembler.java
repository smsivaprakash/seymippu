package com.docstore.service.assembler;

import java.util.ArrayList;

import org.springframework.stereotype.Component;

import com.docstore.core.domain.Docstore;
import com.docstore.core.entity.TAccessType;
import com.docstore.core.entity.TBussRule;
import com.docstore.core.entity.TDocstore;
import com.docstore.core.entity.TNotification;

@Component
public class DocstoreEntityAssembler {
	
	public TDocstore mapDocstoreModelToEntity(Docstore docstore){
		TDocstore tDocstore = null;
		if(null != docstore){
			System.out.println("in entity assembler...");
			tDocstore = new TDocstore();
			tDocstore.setDocstoreId(docstore.getDocstoreId());
			tDocstore.setDocstoreName(docstore.getDocstoreName());
			tDocstore.setDescription(docstore.getDescription());
			tDocstore.setCreatedBy(docstore.getCreatedBy());
			tDocstore.setCreateDt(docstore.getCreatedDate());
//			tDocstore.setTAccessTypes(new ArrayList<TAccessType>());
//			tDocstore.setTBussRules(new ArrayList<TBussRule>());
//			tDocstore.setTNotifications(new ArrayList<TNotification>());
			System.out.println("tDocstoreName "+tDocstore.getDocstoreName());
			System.out.println("tDocstoreDescription "+tDocstore.getDescription());
		}
		return tDocstore;
	}

}
