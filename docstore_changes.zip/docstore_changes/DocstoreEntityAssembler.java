package com.docstore.service.assembler;

import java.util.Date;

import org.springframework.stereotype.Component;

import com.docstore.core.domain.Docstore;
import com.docstore.core.entity.TDocstore;

@Component
public class DocstoreEntityAssembler {
	
	public TDocstore mapDocstoreModelToEntity(Docstore docstore){
		TDocstore tDocstore = null;
		if(null != docstore){
			System.out.println("in entity assembler...");
			tDocstore = new TDocstore();
			tDocstore.setDocstoreId(docstore.getDocstoreId());
			tDocstore.setDocstoreName(docstore.getDocstoreName());
			tDocstore.setDescription(docstore.getDescription());
			tDocstore.setCreatedBy(docstore.getCreatedBy());
			tDocstore.setCreateDt(new Date());
//			tDocstore.setTAccessTypes(new ArrayList<TAccessType>());
//			tDocstore.setTBussRules(new ArrayList<TBussRule>());
//			tDocstore.setTNotifications(new ArrayList<TNotification>());
			System.out.println("tDocstoreName "+tDocstore.getDocstoreName());
			System.out.println("tDocstoreDescription "+tDocstore.getDescription());
		}
		return tDocstore;
	}

}
