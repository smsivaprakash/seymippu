package com.docstore.service.assembler;

import org.springframework.stereotype.Component;

import com.docstore.core.domain.Docstore;
import com.docstore.core.entity.TDocstore;

@Component
public class DocstoreModelAssembler {
	
	public Docstore mapDocstoreEntityToModel(TDocstore tDocstore){
		Docstore docstore = null;
		if(null != tDocstore){
			System.out.println("in model assembler...");
			docstore = new Docstore();
			docstore.setDocstoreId(tDocstore.getDocstoreId());
			docstore.setDocstoreName(tDocstore.getDocstoreName());
			docstore.setDescription(tDocstore.getDescription());
			docstore.setCreatedBy(tDocstore.getCreatedBy());
			docstore.setCreatedDate(tDocstore.getCreateDt().toString());
			System.out.println("docstoreId "+docstore.getDocstoreId());
			System.out.println("docstoreName "+docstore.getDocstoreName());
		}
		return docstore;
	}

}
