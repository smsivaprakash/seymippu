package com.docstore.service;

import java.util.List;

import com.docstore.core.domain.Docstore;
import com.docstore.core.domain.UserDetails;
import com.docstore.core.exception.DocstoreServiceException;

public interface DocstoreService {
	
	public boolean createDocstore(Docstore docstore) throws DocstoreServiceException;
	
	public List<Docstore> fetchDocstoresByUserId(UserDetails userDetails) throws DocstoreServiceException;
	
	public void deleteDocstore(Integer docstoreId) throws DocstoreServiceException;

}
