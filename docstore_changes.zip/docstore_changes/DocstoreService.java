package com.docstore.service;

import java.io.File;
import java.io.InputStream;
import java.util.List;

import com.docstore.core.domain.AccessType;
import com.docstore.core.domain.BusinessRule;
import com.docstore.core.domain.Docstore;
import com.docstore.core.domain.Notification;
import com.docstore.core.domain.ObjectDescriptor;
import com.docstore.core.domain.UserDetails;
import com.docstore.core.exception.DocstoreServiceException;

public interface DocstoreService {
	
	public boolean createDocstore(Docstore docstore) throws DocstoreServiceException;
	
	public List<Docstore> fetchDocstoresByUserId(UserDetails userDetails) throws DocstoreServiceException;
	
	public boolean deleteDocstore(Integer docstoreId, String docstoreName) throws DocstoreServiceException;
	
	public List<ObjectDescriptor> getObjectDescriptors(String docstoreName,String prefix, String key) throws DocstoreServiceException;
	
	public boolean uploadObject(String uploadDirectory, String key, InputStream inputStream, long fileSize) throws DocstoreServiceException;
	
	public boolean downloadObject(String docstoreName, String prefix, String key, String version) throws DocstoreServiceException;
	
	public boolean createFolder(String docstoreName, String prefix, String folderName) throws DocstoreServiceException;
	
	public AccessType getAccessType(String docstoreName, UserDetails details) throws DocstoreServiceException;
	
	public List<BusinessRule> fetchBusinessRules(String docstoreName) throws DocstoreServiceException;
	
	public boolean addBusinessRule(BusinessRule businessRule) throws DocstoreServiceException;
	
	public boolean editBusinessRule(BusinessRule businessRule, String existingRuleName) throws DocstoreServiceException;
	
	public boolean deleteBusinessRule(String ruleName, String docstoreName) throws DocstoreServiceException;
	
	public boolean createFile(String docstoreName, String filePath, File file) throws DocstoreServiceException;
	
	public void sendMail(Notification notification, UserDetails userDetails);
	
	public boolean updateNotifications(String docstoreName, String notificationName, String[] event) throws DocstoreServiceException;
	
	public String findNotificationEventsByDocstore(String docstoreName) throws DocstoreServiceException;
	
	public boolean deleteFiles(String docstoreName, String prefix, String[] deleteKeys) throws DocstoreServiceException;
	
	public boolean copyFiles(String docstoreName, String sourcePrefix, String destinationPrefix, String[] copiedFiles) throws DocstoreServiceException;

}
