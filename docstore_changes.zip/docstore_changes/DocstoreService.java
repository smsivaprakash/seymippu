package com.docstore.service;

import java.io.InputStream;
import java.util.List;

import com.docstore.core.domain.Docstore;
import com.docstore.core.domain.ObjectDescriptor;
import com.docstore.core.domain.UserDetails;
import com.docstore.core.exception.DocstoreServiceException;

public interface DocstoreService {
	
	public boolean createDocstore(Docstore docstore) throws DocstoreServiceException;
	
	public List<Docstore> fetchDocstoresByUserId(UserDetails userDetails) throws DocstoreServiceException;
	
	public boolean deleteDocstore(Integer docstoreId, String docstoreName) throws DocstoreServiceException;
	
	public List<ObjectDescriptor> getObjectDescriptors(String docstoreName,String prefix) throws DocstoreServiceException;
	
	public boolean uploadObject(String uploadDirectory, String key, InputStream inputStream, long fileSize) throws DocstoreServiceException;
	
	public boolean downloadObject(String docstoreName, String prefix, String key) throws DocstoreServiceException;
	
	public boolean createFolder(String docstoreName, String prefix, String folderName) throws DocstoreServiceException;

}
