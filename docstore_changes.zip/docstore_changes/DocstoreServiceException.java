package com.docstore.core.exception;


public class DocstoreServiceException extends BusinessException{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -3764199725916045852L;
	
	public enum DocstoreServiceExceptionCode {

		DOC_SER_EX_CD_001("DOC_SER_EX_CD_001"),
		DOC_SER_EX_CD_002("DOC_SER_EX_CD_002"),
		DOC_SER_EX_CD_003("DOC_SER_EX_CD_003"),
		DOC_SER_EX_CD_004("DOC_SER_EX_CD_004"),
		DOC_SER_EX_CD_005("DOC_SER_EX_CD_005");

		private final String code;

		private DocstoreServiceExceptionCode(String code) {
			this.code = code;
		}
		public String getCode() {
			return this.code;
		}		
	}

	/**
	 * 
	 * @param code
	 * @param message
	 */
	public DocstoreServiceException(String code, String message) {
		super(code, message);
	}

	/**
	 * Instantiates a new docstore service exception.
	 *
	 * @param exceptionCode the exception code
	 * @param exceptionContext the exception context
	 * @param args the args
	 * @param cause the cause
	 */
	public DocstoreServiceException(DocstoreServiceExceptionCode exceptionCode, final String exceptionContext, final Object[] args, final Throwable cause) {
		super (exceptionCode.getCode(), exceptionContext, args, cause);
	}		

}
