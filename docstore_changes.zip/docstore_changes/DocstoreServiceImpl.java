package com.docstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.docstore.core.domain.Docstore;
import com.docstore.core.domain.UserDetails;
import com.docstore.core.exception.DocstoreDataAccessException;
import com.docstore.core.exception.DocstoreServiceException;
import com.docstore.core.exception.DocstoreServiceException.DocstoreServiceExceptionCode;
import com.docstore.dao.service.DocstoreDAOService;
import com.docstore.service.aws.AWSS3Service;

@Service("docstoreService")
public class DocstoreServiceImpl implements DocstoreService{
	
	@Autowired
	AWSS3Service awss3Service;
	
	@Autowired
	DocstoreDAOService docstoreDAOService;
	
	@Transactional
	public boolean createDocstore(Docstore docstore)
			throws DocstoreServiceException {
		boolean docstoreCreated = false;
		try{
			if(null != docstore && null != docstore.getDocstoreName()){
				if(awss3Service.createBucket(docstore.getDocstoreName())){
					System.out.println("persisting docstore");
					Docstore persistedDocstore = docstoreDAOService.createDocstore(docstore);
					if(null != persistedDocstore){
						docstoreCreated = true;
						System.out.println("docstore created successfully with name: "+persistedDocstore.getDocstoreName()+" desc "+persistedDocstore.getDescription());
						System.out.println("docstore created successfully with id: "+persistedDocstore.getDocstoreId());
					}
				}
			}
		}
		catch(AmazonServiceException e){
			System.out.println("AmazonServiceException");
			System.out.println("Message: "+e.getMessage());
			System.out.println("RequestId: "+e.getRequestId());
			throw new DocstoreServiceException(DocstoreServiceExceptionCode.DOC_SER_EX_CD_002, "error while creating docstore", null, e);
		}
		catch(AmazonClientException e){
			System.out.println("AmazonClientException");
			System.out.println("Message: "+e.getMessage());
			throw new DocstoreServiceException(DocstoreServiceExceptionCode.DOC_SER_EX_CD_001, "error while connecting to AWS", null, e);
		}
		catch(DocstoreDataAccessException e){
			throw new DocstoreServiceException(DocstoreServiceExceptionCode.DOC_SER_EX_CD_002, "error while creating docstore", null, e);
		}
		catch(Exception e){
			System.out.println("Exception");
			System.out.println("Message: "+e.getMessage());
			throw new DocstoreServiceException(DocstoreServiceExceptionCode.DOC_SER_EX_CD_002, "error while creating docstore", null, e);
		}
		return docstoreCreated;
	}

	public List<Docstore> fetchDocstoresByUserId(UserDetails userDetails)
			throws DocstoreServiceException {
		try{
			return docstoreDAOService.fetchDocstoresByUserId(userDetails);
		}
		catch(DocstoreDataAccessException e){
			throw new DocstoreServiceException(DocstoreServiceExceptionCode.DOC_SER_EX_CD_003, "error while fetching docstores", null, e);
		}
	}
	
	@Transactional
	public boolean deleteDocstore(Integer docstoreId, String docstoreName) throws DocstoreServiceException {
		try{
			if(awss3Service.deleteBucket(docstoreName)){
				return docstoreDAOService.deleteDocstore(docstoreId);
			}
		}
		catch(DocstoreDataAccessException e){
			throw new DocstoreServiceException(DocstoreServiceExceptionCode.DOC_SER_EX_CD_004, "error while deleting docstore", null, e);
		}
		return false;
	}

}
