package com.docstore.service;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.docstore.core.domain.Docstore;
import com.docstore.core.domain.ObjectDescriptor;
import com.docstore.core.domain.UserDetails;
import com.docstore.core.exception.DocstoreDataAccessException;
import com.docstore.core.exception.DocstoreServiceException;
import com.docstore.core.exception.DocstoreServiceException.DocstoreServiceExceptionCode;
import com.docstore.core.util.ContentTypeUtil;
import com.docstore.dao.service.DocstoreDAOService;
import com.docstore.service.aws.AWSS3Service;

@Service("docstoreService")
public class DocstoreServiceImpl implements DocstoreService{
	
	@Value("${docstore.downloadPath:''}")
	private String downloadPath;
	
	@Autowired
	AWSS3Service awss3Service;
	
	@Autowired
	ContentTypeUtil contentTypeUtil;
	
	@Autowired
	DocstoreDAOService docstoreDAOService;
	
	@Transactional
	public boolean createDocstore(Docstore docstore) throws DocstoreServiceException {
		boolean docstoreCreated = false;
		try{
			if(null != docstore && null != docstore.getDocstoreName()){
				if(awss3Service.createBucket(docstore.getDocstoreName())){
					System.out.println("persisting docstore");
					Docstore persistedDocstore = docstoreDAOService.createDocstore(docstore);
					if(null != persistedDocstore){
						docstoreCreated = true;
						System.out.println("docstore created successfully with name: "+persistedDocstore.getDocstoreName()+" desc "+persistedDocstore.getDescription());
						System.out.println("docstore created successfully with id: "+persistedDocstore.getDocstoreId());
					}
				}
			}
		}
		catch(AmazonServiceException e){
			System.out.println("AmazonServiceException");
			System.out.println("Message: "+e.getMessage());
			System.out.println("RequestId: "+e.getRequestId());
			throw new DocstoreServiceException(DocstoreServiceExceptionCode.DOC_SER_EX_CD_002, "error while creating docstore", null, e);
		}
		catch(AmazonClientException e){
			System.out.println("AmazonClientException");
			System.out.println("Message: "+e.getMessage());
			throw new DocstoreServiceException(DocstoreServiceExceptionCode.DOC_SER_EX_CD_001, "error while connecting to AWS", null, e);
		}
		catch(DocstoreDataAccessException e){
			throw new DocstoreServiceException(DocstoreServiceExceptionCode.DOC_SER_EX_CD_002, "error while creating docstore", null, e);
		}
		catch(Exception e){
			System.out.println("Exception");
			System.out.println("Message: "+e.getMessage());
			throw new DocstoreServiceException(DocstoreServiceExceptionCode.DOC_SER_EX_CD_002, "error while creating docstore", null, e);
		}
		return docstoreCreated;
	}

	public List<Docstore> fetchDocstoresByUserId(UserDetails userDetails)
			throws DocstoreServiceException {
		try{
			return docstoreDAOService.fetchDocstoresByUserId(userDetails);
		}
		catch(DocstoreDataAccessException e){
			throw new DocstoreServiceException(DocstoreServiceExceptionCode.DOC_SER_EX_CD_003, "error while fetching docstores", null, e);
		}
	}
	
	@Transactional
	public boolean deleteDocstore(Integer docstoreId, String docstoreName) throws DocstoreServiceException {
		try{
			if(awss3Service.deleteBucket(docstoreName)){
				return docstoreDAOService.deleteDocstore(docstoreId);
			}
		}
		catch(AmazonServiceException e){
			System.out.println("AmazonServiceException");
			System.out.println("Message: "+e.getMessage());
			System.out.println("RequestId: "+e.getRequestId());
			throw new DocstoreServiceException(DocstoreServiceExceptionCode.DOC_SER_EX_CD_004, "error while deleting docstore", null, e);
		}
		catch(AmazonClientException e){
			System.out.println("AmazonClientException");
			System.out.println("Message: "+e.getMessage());
			throw new DocstoreServiceException(DocstoreServiceExceptionCode.DOC_SER_EX_CD_001, "error while connecting to AWS", null, e);
		}
		catch(DocstoreDataAccessException e){
			throw new DocstoreServiceException(DocstoreServiceExceptionCode.DOC_SER_EX_CD_004, "error while deleting docstore", null, e);
		}
		catch(Exception e){
			System.out.println("Exception");
			System.out.println("Message: "+e.getMessage());
			throw new DocstoreServiceException(DocstoreServiceExceptionCode.DOC_SER_EX_CD_004, "error while deleting docstore", null, e);
		}
		return false;
	}

	public List<ObjectDescriptor> getObjectDescriptors(String docstoreName, String prefix) throws DocstoreServiceException {
		List<ObjectDescriptor> objectDescriptors = null;
		Map<S3ObjectSummary, ObjectMetadata> objectMap = awss3Service.getObjectSummaryList(docstoreName, prefix);
		if(null != objectMap && !objectMap.isEmpty()){
			objectDescriptors = new ArrayList<ObjectDescriptor>();
			for(Map.Entry<S3ObjectSummary, ObjectMetadata> objectEntry : objectMap.entrySet()){
				ObjectDescriptor objectDescriptor = new ObjectDescriptor();
				objectDescriptor.setObjectIdentifier(objectEntry.getKey().getKey());
				objectDescriptor.setSize(objectEntry.getKey().getSize()+" bytes");
				objectDescriptor.setLastModified(objectEntry.getKey().getLastModified().toString());
				if(objectEntry.getValue().getContentType().equals("binary/octet-stream")){
					objectDescriptor.setContentType("folder");
				}
				else{
					objectDescriptor.setContentType("file");
				}
				
				objectDescriptors.add(objectDescriptor);
			}
		}
		return objectDescriptors;
	}

	public boolean uploadObject(String uploadDirectory,String key, InputStream inputStream) throws DocstoreServiceException {
		try{
			String extension = key.substring(key.lastIndexOf(".")+1);
			String contentType = contentTypeUtil.getContentTypes().get(extension);
			if(!contentType.equals("text/plain")){
				System.out.println("content type enum not working");
				contentType = "text/plain";
			}
			return awss3Service.uploadObject(uploadDirectory, key, contentType, inputStream);
		}
		catch(AmazonServiceException e){
			System.out.println("AmazonServiceException");
			System.out.println("Message: "+e.getMessage());
			System.out.println("RequestId: "+e.getRequestId());
			throw new DocstoreServiceException(DocstoreServiceExceptionCode.DOC_SER_EX_CD_005, "error while uploading object to docstore", null, e);
		}
		catch(AmazonClientException e){
			System.out.println("AmazonClientException");
			System.out.println("Message: "+e.getMessage());
			throw new DocstoreServiceException(DocstoreServiceExceptionCode.DOC_SER_EX_CD_001, "error while connecting to AWS", null, e);
		} catch (InterruptedException e) {
			System.out.println("InterruptedException");
			System.out.println("Message: "+e.getMessage());
			throw new DocstoreServiceException(DocstoreServiceExceptionCode.DOC_SER_EX_CD_005, "error while uploading object to docstore", null, e);
		}
	}

	public boolean downloadObject(String docstoreName, String prefix, String key) throws DocstoreServiceException {
		try{
			
			return awss3Service.downloadObject(docstoreName, prefix, key, downloadPath);
		}
		catch(AmazonServiceException e){
			System.out.println("AmazonServiceException");
			System.out.println("Message: "+e.getMessage());
			System.out.println("RequestId: "+e.getRequestId());
			throw new DocstoreServiceException(DocstoreServiceExceptionCode.DOC_SER_EX_CD_006, "error while downloading object from docstore", null, e);
		}
		catch(AmazonClientException e){
			System.out.println("AmazonClientException");
			System.out.println("Message: "+e.getMessage());
			throw new DocstoreServiceException(DocstoreServiceExceptionCode.DOC_SER_EX_CD_001, "error while connecting to AWS", null, e);
		} catch (InterruptedException e) {
			System.out.println("InterruptedException");
			System.out.println("Message: "+e.getMessage());
			throw new DocstoreServiceException(DocstoreServiceExceptionCode.DOC_SER_EX_CD_006, "error while downloading object from docstore", null, e);
		}
	}

}
