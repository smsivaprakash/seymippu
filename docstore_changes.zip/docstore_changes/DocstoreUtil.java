package com.docstore.core.util;

import org.springframework.stereotype.Component;

import com.docstore.core.domain.AccessPermission;
import com.docstore.core.domain.AccessType;
import com.docstore.core.domain.Docstore;

@Component
public class DocstoreUtil {
	
	public AccessPermission getNewAccessPermission(Docstore docstore){
		AccessPermission accessPermission = null;
		if(null != docstore){
			accessPermission = new AccessPermission();
			accessPermission.setDocstoreId(docstore.getDocstoreId());
			accessPermission.setUserId(docstore.getCreatedBy());
			accessPermission.setAccessType(AccessType.FULLACCESS);
		}
		return accessPermission;
	}

}
