package com.docstore.core.domain;

public enum EventType {
	
	CREATE(1), DELETE(2), COPY(3);

	private Integer id;
	
	private EventType(Integer id) {
		this.id=id;
	}

	public Integer getId(){
		return id;
	}
	
	/**
	 * Gets the event type.
	 *
	 * @param id the id
	 * @return the event type
	 */
	public static EventType getEventType(Integer id) {
		for(EventType eventType : EventType.values()) { 
	        if(eventType.getId().equals(id)){
	        	return eventType;
	        }
	     }
		return null;
	}

}
