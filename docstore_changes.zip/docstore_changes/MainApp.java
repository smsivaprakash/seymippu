package com.docstore.sample.test;

public class MainApp {
	
	public static void main(String args[]){
		String key = "folder1/summa/";
		String[] splitted = key.split("folder1/");
		System.out.println("splitted size: "+splitted.length);
		for(int i=0;i<splitted.length;i++){
			System.out.println("str"+i+" : "+splitted[i]);
		}
		
	}

}
