package com.docstore.sample.test;

import java.io.File;

public class MainApp {
	
	public static void main(String args[]){
		File file = new File("C:\\Users\\399536\\Desktop\\sample.properties");
		System.out.println("file "+file.getName());
//		String prefix = "folder1/test folder/";
//		String key = "folder1/test folder/testing2.txt";
//		String actualValue = key.substring(prefix.length());
//		System.out.println(actualValue);
//		String[] splitted = actualValue.split("/");
//		System.out.println("splitted size: "+splitted.length);
//		for(int i=0;i<splitted.length;i++){
//			System.out.println("str"+i+" : "+splitted[i]);
//		}
		
	}

}
