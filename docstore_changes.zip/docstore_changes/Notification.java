package com.docstore.core.domain;

import java.io.Serializable;
import java.util.List;

public class Notification implements Serializable {

	private static final long serialVersionUID = 2034713561902082377L;
	
	private String notificationEvent;
	
	private String source;
	
	private String destination;
	
	private String docstoreName;
	
	private List<String> fileList;

	public String getNotificationEvent() {
		return notificationEvent;
	}

	public void setNotificationEvent(String notificationEvent) {
		this.notificationEvent = notificationEvent;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}
	
	public String getDocstoreName() {
		return docstoreName;
	}

	public void setDocstoreName(String docstoreName) {
		this.docstoreName = docstoreName;
	}
	
	public List<String> getFileList() {
		return fileList;
	}

	public void setFileList(List<String> fileList) {
		this.fileList = fileList;
	}

}
