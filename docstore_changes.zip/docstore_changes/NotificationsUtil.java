package com.docstore.service;

import java.util.Properties;

import javax.mail.Session;

import org.springframework.stereotype.Component;

import com.docstore.core.domain.Notification;
import com.docstore.core.domain.UserDetails;

@Component
public class NotificationsUtil {
	
	static final int PORT = 25;
	
	public Session getMailSession(){
		Properties props = System.getProperties();
    	props.put("port", PORT);
    	props.put("mail.transport.protocol", "smtps");
    	props.put("mail.smtp.port", PORT); 
    	
    	// Set properties indicating that we want to use STARTTLS to encrypt the connection.
    	// The SMTP session will begin on an unencrypted connection, and then the client
        // will issue a STARTTLS command to upgrade to an encrypted connection.
    	props.put("mail.smtps.auth", "true");
    	props.put("mail.smtp.ssl.enable", "true");

        // Create a Session object to represent a mail session with the specified properties. 
    	Session session = Session.getDefaultInstance(props);
    	return session;
	}
	
	public String getMailSubject(String notificationEvent){
		String subject = null;
		if(null != notificationEvent){
			if(notificationEvent.equals("create")){
				subject = "DocuCloud object created";
			}
			else if(notificationEvent.equals("delete")){
				subject = "DocuCloud object deleted";
			}
			else if(notificationEvent.equals("move")){
				subject = "DocuCloud object moved";
			}
		}
		return subject;
	}
	
	public String getMailContent(Notification notification, UserDetails userDetails){
		String content = null;
		if(null != notification){
			if(notification.getNotificationEvent().equals("create")){
				content = "Dear DocuCloud user, A new object "+notification.getSource()+" has been created in the docstore: "+notification.getDocstoreName()+" by "+userDetails.getUserName();
				
				content = "<p><span style=\"font-size: 10.0pt; line-height: 115%; font-family: &amp; amp;\">Dear DocuCloud User,<o:p></o:p></span></p>"+
				"<p><span style=\"font-size: 10.0pt; line-height: 115%; font-family: &amp; amp;\"><br></span></p>"+
				"<p><span style=\"font-size: 10.0pt; line-height: 115%; font-family: &amp; amp;\">A new object <b>"+notification.getSource()+"</b> has been created in the docstore: <b>"+notification.getDocstoreName()+"</b> by "+userDetails.getUserName()+".<o:p></o:p></span></p>"+
				"<p><span style=\"font-size: 10.0pt; line-height: 115%; font-family: &amp; amp;\"><br></span></p>"+
				"<p><span style=\"font-size: 10.0pt; line-height: 115%; font-family: &amp; amp;\">Cheers,</span></p>"+
				"<p><span style=\"font-size: 10.0pt; line-height: 115%; font-family: &amp; amp;\">DocuCloud<o:p></o:p></span></p>";
			}
			else if(notification.getNotificationEvent().equals("delete")){
				content = "Dear DocuCloud user, the object "+notification.getSource()+" has been deleted by "+userDetails.getUserName();
			}
			else if(notification.getNotificationEvent().equals("move")){
				content = "Dear DocuCloud user, the object "+notification.getSource()+" has been moved to "+notification.getDestination();
			}
		}
		return content;
	}

}
