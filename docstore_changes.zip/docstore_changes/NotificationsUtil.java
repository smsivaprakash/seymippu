package com.docstore.service;

import java.util.Iterator;
import java.util.Properties;

import javax.mail.Session;

import org.springframework.stereotype.Component;

import com.docstore.core.domain.Notification;
import com.docstore.core.domain.UserDetails;

@Component
public class NotificationsUtil {
	
	static final int PORT = 25;
	
	public Session getMailSession(){
		Properties props = System.getProperties();
    	props.put("port", PORT);
    	props.put("mail.transport.protocol", "smtps");
    	props.put("mail.smtp.port", PORT); 
    	
    	// Set properties indicating that we want to use STARTTLS to encrypt the connection.
    	// The SMTP session will begin on an unencrypted connection, and then the client
        // will issue a STARTTLS command to upgrade to an encrypted connection.
    	props.put("mail.smtps.auth", "true");
    	props.put("mail.smtp.ssl.enable", "true");

        // Create a Session object to represent a mail session with the specified properties. 
    	Session session = Session.getDefaultInstance(props);
    	return session;
	}
	
	public String getMailSubject(String notificationEvent){
		String subject = null;
		if(null != notificationEvent){
			if(notificationEvent.equals("create")){
				subject = "DocuCloud object created";
			}
			else if(notificationEvent.equals("delete")){
				subject = "DocuCloud object deleted";
			}
			else if(notificationEvent.equals("copy")){
				subject = "DocuCloud object copied";
			}
		}
		return subject;
	}
	
	public String getMailContent(Notification notification, UserDetails userDetails){
		String content = null;
		if(null != notification){
			if(notification.getNotificationEvent().equals("create")){
				content = "<p><span style=\"font-size: 10.0pt; line-height: 115%; font-family: &amp; amp;\">Dear DocuCloud User,<o:p></o:p></span></p>"+
				"<p><span style=\"font-size: 10.0pt; line-height: 115%; font-family: &amp; amp;\"><br></span></p>"+
				"<p><span style=\"font-size: 10.0pt; line-height: 115%; font-family: &amp; amp;\">A new object <b>"+notification.getSource()+"</b> has been created in the docstore: <b>"+notification.getDocstoreName()+"</b> by "+userDetails.getUserName()+".<o:p></o:p></span></p>"+
				"<p><span style=\"font-size: 10.0pt; line-height: 115%; font-family: &amp; amp;\"><br></span></p>"+
				"<p><span style=\"font-size: 10.0pt; line-height: 115%; font-family: &amp; amp;\">Cheers,</span></p>"+
				"<p><span style=\"font-size: 10.0pt; line-height: 115%; font-family: &amp; amp;\">DocuCloud<o:p></o:p></span></p>";
			}
			else if(notification.getNotificationEvent().equals("delete")){
				content = "<p class=\"MsoNormal\"><span style=\"font-size: 10pt; line-height: 115%; font-family: &quot;Segoe UI&quot;, sans-serif; color: black; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">Dear DocuCloud User,<o:p></o:p></span></p>"+
						"<p class=\"MsoNormal\"><span style=\"font-size: 10pt; line-height: 115%; font-family: &quot;Segoe UI&quot;, sans-serif; color: black; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><br></span></p>"+
						"<p class=\"MsoNormal\"><span style=\"font-size: 10pt; line-height: 115%; font-family: &quot;Segoe UI&quot;, sans-serif; color: black; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">The following objects have been deleted from the docstore: <b>"+notification.getSource()+"</b> by "+userDetails.getUserName()+".<o:p></o:p></span></p>"+
						"<p class=\"MsoListParagraphCxSpFirst\" style=\"text-indent:-18.0pt;mso-list:l0 level1 lfo1\"><ul>";
				Iterator<String> iterator = notification.getFileList().iterator();
				while(iterator.hasNext()){
					content = content + "<li><span style=\"font-variant-numeric: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style=\"text-indent: -18pt; font-size: 10pt; line-height: 115%; font-family: &quot;Segoe UI&quot;, sans-serif;\">"+iterator.next()+"</span><br></li>";
				}
				content = content + "</ul><!--[if !supportLists]--></p>"+
				"<p class=\"MsoListParagraphCxSpLast\" style=\"text-indent:-18.0pt;mso-list:l0 level1 lfo1\"><span style=\"font-size:10.0pt;line-height:115%;font-family:&quot;Segoe UI&quot;,&quot;sans-serif&quot;\"><br></span></p>"+
				"<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;line-height:115%;font-family:&quot;Segoe UI&quot;,&quot;sans-serif&quot;\">Cheers,<o:p></o:p></span></p>"+
				"<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;line-height:115%;font-family:&quot;Segoe UI&quot;,&quot;sans-serif&quot;\">DocuCloud<o:p></o:p></span></p>";
			}
			else if(notification.getNotificationEvent().equals("copy")){
				content = "<p class=\"MsoNormal\"><span style=\"font-size: 10pt; line-height: 115%; font-family: &quot;Segoe UI&quot;, sans-serif; color: black; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">Dear DocuCloud User,<o:p></o:p></span></p>"+
						"<p class=\"MsoNormal\"><span style=\"font-size: 10pt; line-height: 115%; font-family: &quot;Segoe UI&quot;, sans-serif; color: black; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\"><br></span></p>"+
						"<p class=\"MsoNormal\"><span style=\"font-size: 10pt; line-height: 115%; font-family: &quot;Segoe UI&quot;, sans-serif; color: black; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;\">The following objects have been copied from the docstore: <b>"+notification.getSource()+"</b> to <b>"+notification.getDestination()+"</b> by "+userDetails.getUserName()+".<o:p></o:p></span></p>"+
						"<p class=\"MsoListParagraphCxSpFirst\" style=\"text-indent:-18.0pt;mso-list:l0 level1 lfo1\"><ul>";
				Iterator<String> iterator = notification.getFileList().iterator();
				while(iterator.hasNext()){
					content = content + "<li><span style=\"font-variant-numeric: normal; font-stretch: normal; font-size: 7pt; line-height: normal; font-family: &quot;Times New Roman&quot;;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><span style=\"text-indent: -18pt; font-size: 10pt; line-height: 115%; font-family: &quot;Segoe UI&quot;, sans-serif;\">"+iterator.next()+"</span><br></li>";
				}
				content = content + "</ul><!--[if !supportLists]--></p>"+
				"<p class=\"MsoListParagraphCxSpLast\" style=\"text-indent:-18.0pt;mso-list:l0 level1 lfo1\"><span style=\"font-size:10.0pt;line-height:115%;font-family:&quot;Segoe UI&quot;,&quot;sans-serif&quot;\"><br></span></p>"+
				"<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;line-height:115%;font-family:&quot;Segoe UI&quot;,&quot;sans-serif&quot;\">Cheers,<o:p></o:p></span></p>"+
				"<p class=\"MsoNormal\"><span style=\"font-size:10.0pt;line-height:115%;font-family:&quot;Segoe UI&quot;,&quot;sans-serif&quot;\">DocuCloud<o:p></o:p></span></p>";
			}
		}
		return content;
	}

}
