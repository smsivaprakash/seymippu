package com.docstore.core.domain;

import java.io.Serializable;

public class ObjectDescriptor implements Serializable{

	private static final long serialVersionUID = 8377035008225460051L;
	
	private Integer objectId;
	
	private String objectIdentifier;
	
	private String size;
	
	private String contentType;
	
	private String lastModified;

	public Integer getObjectId() {
		return objectId;
	}

	public void setObjectId(Integer objectId) {
		this.objectId = objectId;
	}

	public String getObjectIdentifier() {
		return objectIdentifier;
	}

	public void setObjectIdentifier(String objectIdentifier) {
		this.objectIdentifier = objectIdentifier;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getLastModified() {
		return lastModified;
	}

	public void setLastModified(String lastModified) {
		this.lastModified = lastModified;
	}

}
