package com.docstore.portal.common;

import java.io.Serializable;

public class ServiceResponse<T> implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -975910310780313504L;
	
	/** The status. */
	private ServiceStatus status;

	/** The result. */
	private ServiceResult<T> result;

	/**
	 * Gets the status.
	 *
	 * @return the status
	 * @Method getStatus - getters and setters.
	 */
	
	//@JsonProperty("status_text")
	public ServiceStatus getStatus() {
		return status;
	}

	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 * @Method setStatus - Sets the status.
	 */
	public void setStatus(ServiceStatus status) {
		this.status = status;
	}

	/**
	 * Gets the result.
	 *
	 * @return the result
	 * @Method getResult - Gets the result.
	 */
	public ServiceResult<T> getResult() {
		return result;
	}

	/**
	 * Sets the result.
	 *
	 * @param result the new result
	 * @Method setResult - Sets the result.
	 */
	public void setResult(ServiceResult<T> result) {
		this.result = result;
	}


}
