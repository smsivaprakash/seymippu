package com.docstore.portal.common;

import java.io.Serializable;
import java.util.List;

public class ServiceResult<T> implements Serializable{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 5420219098048827085L;
	
	/** The detail. */
	private T detail;
	
	/** The list. */
	private List<T> list;

	public T getDetail() {
		return detail;
	}

	public void setDetail(T detail) {
		this.detail = detail;
	}

	public List<T> getList() {
		return list;
	}

	public void setList(List<T> list) {
		this.list = list;
	}

}
