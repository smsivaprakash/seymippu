package com.docstore.portal.common;

import java.io.Serializable;

public class ServiceStatus implements Serializable{

	private static final long serialVersionUID = 5243595745036526132L;
	
	private int statusCode;
	
	private String message;

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
