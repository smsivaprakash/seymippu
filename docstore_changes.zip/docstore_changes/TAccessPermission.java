package com.docstore.core.entity;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "t_access_permission")
@NamedQueries({
	@NamedQuery(name = "fetchUserDetailsByDocstoreId", query = "SELECT myTAccessPermission.tUsr.email from TAccessPermission myTAccessPermission join myTAccessPermission.tUsr myTUsr where myTAccessPermission.tDocstore.docstoreId = ?1 ")
})
public class TAccessPermission implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	private TAccessPermissionId tAccessPermissionId;
	
	@OneToOne
	@JoinColumn(name = "usr_id", referencedColumnName = "usr_id", nullable = false, insertable = false, updatable = false)
	private TUsr tUsr;
	
	@OneToOne
	@JoinColumn(name = "docstore_id", referencedColumnName = "docstore_id", nullable = false, insertable = false, updatable = false)
	private TDocstore tDocstore;
	
	@OneToOne
	@JoinColumn(name = "access_type_id", referencedColumnName = "access_type_id", nullable = false)
	private TAccessType tAccessType;

	public TAccessPermissionId gettAccessPermissionId() {
		return tAccessPermissionId;
	}

	public void settAccessPermissionId(TAccessPermissionId tAccessPermissionId) {
		this.tAccessPermissionId = tAccessPermissionId;
	}

	public TUsr gettUsr() {
		return tUsr;
	}

	public void settUsr(TUsr tUsr) {
		this.tUsr = tUsr;
	}

	public TDocstore gettDocstore() {
		return tDocstore;
	}

	public void settDocstore(TDocstore tDocstore) {
		this.tDocstore = tDocstore;
	}
	
	public TAccessType gettAccessType() {
		return tAccessType;
	}

	public void settAccessType(TAccessType tAccessType) {
		this.tAccessType = tAccessType;
	}
	
//	/**
//	 * @generated
//	 * 
//	 */
//	@Override
//	public int hashCode() {
//		int prime = 31;
//		int result = 1;
//		result = prime * result + ((tAccessPermissionId == null) ? 0 : tAccessPermissionId.hashCode());
//		return result;
//	}
//	
//	/**
//	 * @generated
//	 * 
//	 */
//	@Override
//	public boolean equals(final Object obj) {
//
//		if (this == obj) {
//			return true;
//		}
//		if (obj == null) {
//			return false;
//		}
//		if (getClass() != obj.getClass()) {
//			return false;
//		}
//		final TAccessPermission other = (TAccessPermission) obj;
//		if (tAccessPermissionId == null) {
//			if (other.tAccessPermissionId != null) {
//				return false;
//			}
//		} else if (!tAccessPermissionId.equals(other.tAccessPermissionId)) {
//			return false;
//		}
//		return true;
//	}

}
