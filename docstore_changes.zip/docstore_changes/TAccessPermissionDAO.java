package com.docstore.core.dao;

import java.util.List;

import com.docstore.core.entity.TAccessPermission;
import com.docstore.core.entity.TAccessPermissionId;

public interface TAccessPermissionDAO {
	
	/**
	 * Stores a new TAccessPermission entity object in to the persistent store
	 * 
	 * @param tAccessPermission TAccessPermission Entity object to be persisted
	 * @return tAccessPermission Persisted TAccessPermission object
	 */
	TAccessPermission createTAccessPermission(TAccessPermission tAccessPermission);

	/**
	 * Deletes a TAccessPermission entity object from the persistent store
	 * 
	 * @param tAccessPermission TAccessPermission Entity object to be deleted
	 */
	void deleteTAccessPermission(Integer tAccessPermissionId);

	/**
	 * Updates a TAccessPermission entity object in to the persistent store
	 * 
	 * @param tAccessPermission TAccessPermission Entity object to be updated
	 * @return tAccessPermission Persisted TAccessPermission object
	 */
	TAccessPermission updateTAccessPermission(TAccessPermission tAccessPermission);

	/**
	 * Retrieve an TAccessPermission object based on given docstoreId and userId.
	 * 
	 * @param tAccessPermissionId the composite key value of the TAccessPermission Entity.
	 * @param tUsrId the composite key value of the TAccessPermission Entity.
	 * @return an Object if it exists against given primary key. Returns null of not found
	 */
	TAccessPermission findTAccessPermission(TAccessPermissionId tAccessPermissionId);
	
	/**
	 * Fetch email list by docstore name.
	 *
	 * @param docstoreId the docstore id
	 * @return the list
	 */
	List<String> fetchEmailListByDocstoreName(Integer docstoreId);
	
	/**
	 * Fetch docstores by user id.
	 *
	 * @param userId the user id
	 * @return the list
	 */
	List<TAccessPermission> fetchDocstoresByUserId(Integer userId);
	
	/**
	 * Fetch all access permissions.
	 *
	 * @param docstoreId the docstore id
	 * @return the list
	 */
	List<TAccessPermission> fetchAllAccessPermissions(Integer docstoreId);

}
