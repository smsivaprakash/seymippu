package com.docstore.core.dao;

import com.docstore.core.entity.TAccessPermission;

public interface TAccessPermissionDAO {
	
	/**
	 * Stores a new TAccessPermission entity object in to the persistent store
	 * 
	 * @param tAccessPermission TAccessPermission Entity object to be persisted
	 * @return tAccessPermission Persisted TAccessPermission object
	 */
	TAccessPermission createTAccessPermission(TAccessPermission tAccessPermission);

	/**
	 * Deletes a TAccessPermission entity object from the persistent store
	 * 
	 * @param tAccessPermission TAccessPermission Entity object to be deleted
	 */
	void deleteTAccessPermission(Integer tAccessPermissionId);

	/**
	 * Updates a TAccessPermission entity object in to the persistent store
	 * 
	 * @param tAccessPermission TAccessPermission Entity object to be updated
	 * @return tAccessPermission Persisted TAccessPermission object
	 */
	TAccessPermission updateTAccessPermission(TAccessPermission tAccessPermission);

	/**
	 * Retrieve an TAccessPermission object based on given docstoreId and userId.
	 * 
	 * @param tDocstoreId the composite key value of the TAccessPermission Entity.
	 * @param tUsrId the composite key value of the TAccessPermission Entity.
	 * @return an Object if it exists against given primary key. Returns null of not found
	 */
	TAccessPermission findTAccessPermission(Integer tAccessPermissionId);

}
