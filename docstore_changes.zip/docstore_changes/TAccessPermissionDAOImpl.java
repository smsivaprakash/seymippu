package com.docstore.core.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.docstore.core.entity.TAccessPermission;

@Repository("tAccessPermissionDAO")
public class TAccessPermissionDAOImpl implements TAccessPermissionDAO{
	
	@Autowired
	private GenericDAO genericDAO;
	
	private final Class<TAccessPermission> clazz;
	
	public TAccessPermissionDAOImpl(){
		super();
		this.clazz = TAccessPermission.class;
	}

	public TAccessPermission createTAccessPermission(
			TAccessPermission tAccessPermission) {
		System.out.println("=========== Create TAccessPermission ===========");		
		return genericDAO.store(tAccessPermission);
	}

	public void deleteTAccessPermission(Integer tAccessPermissionId) {
		System.out.println("=========== delete TAccessPermission ===========");
		final TAccessPermission tAccessPermission = genericDAO.get(clazz, tAccessPermissionId);
		genericDAO.remove(tAccessPermission);
	}

	public TAccessPermission updateTAccessPermission(
			TAccessPermission tAccessPermission) {
		System.out.println("=========== Update TAccessPermission ===========");
		return genericDAO.update(tAccessPermission);
	}

	public TAccessPermission findTAccessPermission(Integer tAccessPermissionId) {
		System.out.println("find TDocstore with docstoreId: " + tAccessPermissionId);
		return genericDAO.get(clazz, tAccessPermissionId);
	}

}
