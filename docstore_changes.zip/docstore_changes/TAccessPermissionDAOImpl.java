package com.docstore.core.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.docstore.core.entity.TAccessPermission;
import com.docstore.core.entity.TAccessPermissionId;

@Repository("tAccessPermissionDAO")
public class TAccessPermissionDAOImpl implements TAccessPermissionDAO{
	
	@Autowired
	private GenericDAO genericDAO;
	
	private final Class<TAccessPermission> clazz;
	
	public TAccessPermissionDAOImpl(){
		super();
		this.clazz = TAccessPermission.class;
	}

	public TAccessPermission createTAccessPermission(
			TAccessPermission tAccessPermission) {
		System.out.println("=========== Create TAccessPermission ===========");		
		return genericDAO.store(tAccessPermission);
	}

	public void deleteTAccessPermission(Integer tAccessPermissionId) {
		System.out.println("=========== delete TAccessPermission ===========");
		final TAccessPermission tAccessPermission = genericDAO.get(clazz, tAccessPermissionId);
		genericDAO.remove(tAccessPermission);
	}

	public TAccessPermission updateTAccessPermission(
			TAccessPermission tAccessPermission) {
		System.out.println("=========== Update TAccessPermission ===========");
		return genericDAO.update(tAccessPermission);
	}

	public TAccessPermission findTAccessPermission(TAccessPermissionId tAccessPermissionId) {
		System.out.println("find TDocstore with docstoreId: " + tAccessPermissionId);
		return genericDAO.get(clazz, tAccessPermissionId);
	}

	public List<String> fetchEmailListByDocstoreName(Integer docstoreId) {
		List<Object> paramList = new ArrayList<Object>();
		paramList.add(docstoreId);
		System.out.println("find email with docstoreId: " + docstoreId);
		return genericDAO.findEntitiesByNamedQueryMultiCond("fetchUserDetailsByDocstoreId", paramList, 0, -1);
	}

}
