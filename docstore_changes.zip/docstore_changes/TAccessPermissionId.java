package com.docstore.core.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class TAccessPermissionId implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Column(name = "usr_id", nullable = false)
    private Integer usrId;

    @Column(name = "docstore_id", nullable = false)
    private Integer docstoreId;

	public int getUsrId() {
		return usrId;
	}

	public void setUsrId(final Integer usrId) {
		this.usrId = usrId;
	}

	public int getDocstoreId() {
		return docstoreId;
	}

	public void setDocstoreId(final Integer docstoreId) {
		this.docstoreId = docstoreId;
	}
	
	/**
	 * 
	 * @generated
	 */
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof TAccessPermissionId)) {
			return false;
		}
		TAccessPermissionId castOther = (TAccessPermissionId) other;
		return (this.usrId.equals(castOther.usrId)) &&

		(this.docstoreId.equals(castOther.docstoreId))

		;

	}

	/**
	 * @generated
	 * 
	 */
	@Override
	public int hashCode() {
		int prime = 31;
		int result = 1;
		result = prime * result + ((usrId == null) ? 0 : usrId.hashCode());
		result = prime * result + ((docstoreId == null) ? 0 : docstoreId.hashCode());
		return result;
	}

}
