package com.docstore.core.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.util.List;


/**
 * The persistent class for the t_access_type database table.
 * 
 */
@Entity
@Table(name="t_access_type")
@NamedQuery(name="TAccessType.findAll", query="SELECT t FROM TAccessType t")
public class TAccessType implements Serializable {
	private static final long serialVersionUID = 1L;
	private int accessTypeId;
	private String accessTypeName;
	private List<TDocstore> TDocstores;

	public TAccessType() {
	}

	@Id
	@Column(name="access_type_id")
	public int getAccessTypeId() {
		return this.accessTypeId;
	}

	public void setAccessTypeId(int accessTypeId) {
		this.accessTypeId = accessTypeId;
	}


	@Column(name="access_type_name")
	public String getAccessTypeName() {
		return this.accessTypeName;
	}

	public void setAccessTypeName(String accessTypeName) {
		this.accessTypeName = accessTypeName;
	}


	//bi-directional many-to-many association to TDocstore
	@ManyToMany
	@JoinTable(
		name="t_access_permission"
		, joinColumns={
			@JoinColumn(name="access_type_id")
			}
		, inverseJoinColumns={
			@JoinColumn(name="docstore_id")
			}
		)
	public List<TDocstore> getTDocstores() {
		return this.TDocstores;
	}

	public void setTDocstores(List<TDocstore> TDocstores) {
		this.TDocstores = TDocstores;
	}

}