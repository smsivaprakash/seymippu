package com.docstore.core.entity;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the t_buss_rule database table.
 * 
 */
@Entity
@Table(name="t_buss_rule")
@NamedQuery(name="TBussRule.findAll", query="SELECT t FROM TBussRule t")
public class TBussRule implements Serializable {
	private static final long serialVersionUID = 1L;
	private int bussRuleId;
	private String bussRuleName;
	private int movementDays;
	private TDocstore TDocstore;

	public TBussRule() {
	}


	@Id
	@Column(name="buss_rule_id")
	public int getBussRuleId() {
		return this.bussRuleId;
	}

	public void setBussRuleId(int bussRuleId) {
		this.bussRuleId = bussRuleId;
	}


	@Column(name="buss_rule_name")
	public String getBussRuleName() {
		return this.bussRuleName;
	}

	public void setBussRuleName(String bussRuleName) {
		this.bussRuleName = bussRuleName;
	}


	@Column(name="movement_days")
	public int getMovementDays() {
		return this.movementDays;
	}

	public void setMovementDays(int movementDays) {
		this.movementDays = movementDays;
	}


	//bi-directional many-to-one association to TDocstore
	@ManyToOne
	@JoinColumn(name="docstore_id")
	public TDocstore getTDocstore() {
		return this.TDocstore;
	}

	public void setTDocstore(TDocstore TDocstore) {
		this.TDocstore = TDocstore;
	}

}