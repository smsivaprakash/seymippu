package com.docstore.core.entity;

import java.io.Serializable;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

import org.hibernate.envers.NotAudited;
import org.hibernate.validator.constraints.Length;

import java.util.Date;
import java.util.List;


/**
 * The persistent class for the t_docstore database table.
 * 
 */
@Entity
@NamedQueries({
	@NamedQuery(name = "fetchDocstoresByUserId", query = "SELECT myTDocstore from TDocstore myTDocstore where myTDocstore.createdBy = ?1 ")
})
@Table(name = "t_docstore", uniqueConstraints = @UniqueConstraint(columnNames = { "docstore_id","docstore_name" }))
public class TDocstore implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "docstore_id", nullable = false, length = 255)
	private Integer docstoreId;
	
	@NotNull
	@Column(name = "create_dt", nullable = false, length = 19, updatable = false)
	private Date createDt;
	
	@NotNull
	@Column(name = "created_by", nullable = false, length = 255, updatable = false)
	private Integer createdBy;
	
	@Length(max = 500)
	@Column(name = "description", nullable = false, length = 500)
	private String description;
	
	@Length(max = 63)
	@Column(name = "docstore_name", nullable = false, length = 63)
	private String docstoreName;
	
	@ManyToMany(mappedBy="TDocstores")
	private List<TAccessType> TAccessTypes;
	
	@OneToMany(cascade = { CascadeType.REFRESH, CascadeType.PERSIST,
			CascadeType.MERGE }, mappedBy = "TDocstore", fetch=FetchType.LAZY )
	@NotAudited
	private List<TBussRule> TBussRules;
	
	@OneToMany(cascade = { CascadeType.REFRESH, CascadeType.PERSIST,
			CascadeType.MERGE }, mappedBy = "TDocstore", fetch=FetchType.LAZY )
	@NotAudited
	private List<TNotification> TNotifications;

	public Integer getDocstoreId() {
		return docstoreId;
	}

	public void setDocstoreId(Integer docstoreId) {
		this.docstoreId = docstoreId;
	}

	public Date getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDocstoreName() {
		return docstoreName;
	}

	public void setDocstoreName(String docstoreName) {
		this.docstoreName = docstoreName;
	}

	public List<TAccessType> getTAccessTypes() {
		return TAccessTypes;
	}

	public void setTAccessTypes(List<TAccessType> tAccessTypes) {
		TAccessTypes = tAccessTypes;
	}

	public List<TBussRule> getTBussRules() {
		return TBussRules;
	}

	public void setTBussRules(List<TBussRule> tBussRules) {
		TBussRules = tBussRules;
	}

	public List<TNotification> getTNotifications() {
		return TNotifications;
	}

	public void setTNotifications(List<TNotification> tNotifications) {
		TNotifications = tNotifications;
	}
	
}