package com.docstore.core.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the t_docstore database table.
 * 
 */
@Entity
@Table(name="t_docstore")
@NamedQuery(name="TDocstore.findAll", query="SELECT t FROM TDocstore t")
public class TDocstore implements Serializable {
	private static final long serialVersionUID = 1L;
	private int docstoreId;
	private Date createDt;
	private int createdBy;
	private String description;
	private String docstoreName;
	private List<TAccessType> TAccessTypes;
	private List<TBussRule> TBussRules;
	private List<TNotification> TNotifications;

	public TDocstore() {
	}


	@Id
	@Column(name="docstore_id")
	public int getDocstoreId() {
		return this.docstoreId;
	}

	public void setDocstoreId(int docstoreId) {
		this.docstoreId = docstoreId;
	}


	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="create_dt")
	public Date getCreateDt() {
		return this.createDt;
	}

	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}


	@Column(name="created_by")
	public int getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}


	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}


	@Column(name="docstore_name")
	public String getDocstoreName() {
		return this.docstoreName;
	}

	public void setDocstoreName(String docstoreName) {
		this.docstoreName = docstoreName;
	}


	//bi-directional many-to-many association to TAccessType
	@ManyToMany(mappedBy="TDocstores")
	public List<TAccessType> getTAccessTypes() {
		return this.TAccessTypes;
	}

	public void setTAccessTypes(List<TAccessType> TAccessTypes) {
		this.TAccessTypes = TAccessTypes;
	}


	//bi-directional many-to-one association to TBussRule
	@OneToMany(mappedBy="TDocstore")
	public List<TBussRule> getTBussRules() {
		return this.TBussRules;
	}

	public void setTBussRules(List<TBussRule> TBussRules) {
		this.TBussRules = TBussRules;
	}

	public TBussRule addTBussRule(TBussRule TBussRule) {
		getTBussRules().add(TBussRule);
		TBussRule.setTDocstore(this);

		return TBussRule;
	}

	public TBussRule removeTBussRule(TBussRule TBussRule) {
		getTBussRules().remove(TBussRule);
		TBussRule.setTDocstore(null);

		return TBussRule;
	}


	//bi-directional many-to-one association to TNotification
	@OneToMany(mappedBy="TDocstore")
	public List<TNotification> getTNotifications() {
		return this.TNotifications;
	}

	public void setTNotifications(List<TNotification> TNotifications) {
		this.TNotifications = TNotifications;
	}

	public TNotification addTNotification(TNotification TNotification) {
		getTNotifications().add(TNotification);
		TNotification.setTDocstore(this);

		return TNotification;
	}

	public TNotification removeTNotification(TNotification TNotification) {
		getTNotifications().remove(TNotification);
		TNotification.setTDocstore(null);

		return TNotification;
	}

}