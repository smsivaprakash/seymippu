package com.docstore.core.dao;

import com.docstore.core.entity.TDocstore;

public interface TDocstoreDAO {
	
	/**
	 * Stores a new TDocstore entity object in to the persistent store
	 * 
	 * @param tDocstore TDocstore Entity object to be persisted
	 * @return tDocstore Persisted TDocstore object
	 */
	TDocstore createTDocstore(TDocstore tDocstore);

	/**
	 * Deletes a TDocstore entity object from the persistent store
	 * 
	 * @param tDocstore TDocstore Entity object to be deleted
	 */
	void deleteTDocstore(Integer tDocstoreId);

	/**
	 * Updates a TDocstore entity object in to the persistent store
	 * 
	 * @param tDocstore TDocstore Entity object to be updated
	 * @return tDocstore Persisted TDocstore object
	 */
	TDocstore updateTDocstore(TDocstore tDocstore);

	/**
	 * Retrieve an TDocstore object based on given docstoreId.
	 * 
	 * @param tDocstoreId the primary key value of the TDocstore Entity.
	 * @return an Object if it exists against given primary key. Returns null of not found
	 */
	TDocstore findTDocstoreById(Integer tDocstoreId);

}
