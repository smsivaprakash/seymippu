package com.docstore.core.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.docstore.core.entity.TDocstore;

@Repository("tDocstoreDAO")
public class TDocstoreDAOImpl implements TDocstoreDAO{
	
	@Autowired
	private GenericDAO genericDAO;
	
	private final Class<TDocstore> clazz;
	
	public TDocstoreDAOImpl(){
		super();
		this.clazz = TDocstore.class;
	}

	public TDocstore createTDocstore(final TDocstore tDocstore) {
		System.out.println("=========== Create TDocstore ===========");		
		return genericDAO.store(tDocstore);
	}

	public void deleteTDocstore(final Integer tDocstoreId) {
		System.out.println("=========== delete TDocstore ===========");
		final TDocstore tDocstore = genericDAO.get(clazz, tDocstoreId);
		genericDAO.remove(tDocstore);
	}

	public TDocstore updateTDocstore(final TDocstore tDocstore) {
		System.out.println("=========== Update TDocstore ===========");
		return genericDAO.update(tDocstore);
	}

	public TDocstore findTDocstoreById(final Integer tDocstoreId) {
		System.out.println("find TDocstore with docstoreId: " + tDocstoreId);
		return genericDAO.get(clazz, tDocstoreId);
	}

	public List<TDocstore> fetchDocstoresByUserId(final Integer userId) {
		List<Object> paramList = new ArrayList<Object>();
		paramList.add(userId);
		return genericDAO.findEntitiesByNamedQueryMultiCond("fetchDocstoresByUserId", paramList, 0, -1);
	}

	public List<TDocstore> fetchDocstoreIdByName(String tDocstoreName) {
		List<Object> paramList = new ArrayList<Object>();
		paramList.add(tDocstoreName);
		return genericDAO.findEntitiesByNamedQueryMultiCond("fetchDocstoreIdByName", paramList, 0, -1);
	}

}
