package com.docstore.core.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.docstore.core.entity.TDocstore;

@Repository("tDocstoreDAO")
public class TDocstoreDAOImpl implements TDocstoreDAO{
	
	@Autowired
	private GenericDAO genericDAO;
	
	private final Class<TDocstore> clazz;
	
	public TDocstoreDAOImpl(){
		super();
		this.clazz = TDocstore.class;
	}

	public TDocstore createTDocstore(TDocstore tDocstore) {
		System.out.println("=========== Create TDocstore ===========");
		
		//TODO delete
		System.out.println("in docstore DAO");
		System.out.println("name: "+tDocstore.getDocstoreName()+" desc: "+tDocstore.getDescription());
		
		return genericDAO.store(tDocstore);
	}

	public void deleteTDocstore(Integer tDocstoreId) {
		// TODO Auto-generated method stub
		
	}

	public TDocstore updateTDocstore(TDocstore tDocstore) {
		// TODO Auto-generated method stub
		return null;
	}

	public TDocstore findTDocstoreById(Integer tDocstoreId) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<TDocstore> fetchDocstoresByUserId(Integer userId) {
		List<Object> paramList = new ArrayList<Object>();
		paramList.add(userId);
		return genericDAO.findEntitiesByNamedQueryMultiCond("fetchDocstoresByUserId", paramList, 0, -1);
	}

}
