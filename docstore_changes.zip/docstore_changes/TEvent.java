package com.docstore.core.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the t_events database table.
 * 
 */
@Entity
@Table(name="t_events")
@NamedQuery(name="TEvent.findAll", query="SELECT t FROM TEvent t")
public class TEvent implements Serializable {
	private static final long serialVersionUID = 1L;
	private int eventId;
	private String eventName;
	private List<TNotification> TNotifications;

	public TEvent() {
	}


	@Id
	@Column(name="event_id")
	public int getEventId() {
		return this.eventId;
	}

	public void setEventId(int eventId) {
		this.eventId = eventId;
	}


	@Column(name="event_name")
	public String getEventName() {
		return this.eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}


	//bi-directional many-to-one association to TNotification
	@OneToMany(mappedBy="TEvent")
	public List<TNotification> getTNotifications() {
		return this.TNotifications;
	}

	public void setTNotifications(List<TNotification> TNotifications) {
		this.TNotifications = TNotifications;
	}

	public TNotification addTNotification(TNotification TNotification) {
		getTNotifications().add(TNotification);
		TNotification.setTEvent(this);

		return TNotification;
	}

	public TNotification removeTNotification(TNotification TNotification) {
		getTNotifications().remove(TNotification);
		TNotification.setTEvent(null);

		return TNotification;
	}

}