package com.docstore.core.entity;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the t_notifications database table.
 * 
 */
@Entity
@Table(name="t_notifications")
@NamedQueries({
	//@NamedQuery(name = "fetchNotificationsByDocstoreId", query = "SELECT myTNotification from TNotification myTNotification where myTNotification.tDocstore.docstoreId = ?1 ")
})
public class TNotification implements Serializable {
	private static final long serialVersionUID = 1L;
	private int notificationId;
	private String notificationName;
	private String prefix;
	private String suffix;
	private TDocstore tDocstore;
	private TEvent tEvent;
	private char activeFlag;

	public TNotification() {
	}


	@Id
	@Column(name="notification_id")
	public int getNotificationId() {
		return this.notificationId;
	}

	public void setNotificationId(int notificationId) {
		this.notificationId = notificationId;
	}


	@Column(name="notification_name")
	public String getNotificationName() {
		return this.notificationName;
	}

	public void setNotificationName(String notificationName) {
		this.notificationName = notificationName;
	}
	
	@Column(name="active_flag")
	public char getActiveFlag() {
		return activeFlag;
	}

	public void setActiveFlag(char activeFlag) {
		this.activeFlag = activeFlag;
	}


	public String getPrefix() {
		return this.prefix;
	}

	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}


	public String getSuffix() {
		return this.suffix;
	}

	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}


	//bi-directional many-to-one association to TDocstore
	@ManyToOne
	@JoinColumn(name="docstore_id")
	public TDocstore getTDocstore() {
		return this.tDocstore;
	}

	public void setTDocstore(TDocstore TDocstore) {
		this.tDocstore = TDocstore;
	}


	//bi-directional many-to-one association to TEvent
	@ManyToOne
	@JoinColumn(name="event_id")
	public TEvent getTEvent() {
		return this.tEvent;
	}

	public void setTEvent(TEvent TEvent) {
		this.tEvent = TEvent;
	}

}