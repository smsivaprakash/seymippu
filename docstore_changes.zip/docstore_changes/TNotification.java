package com.docstore.core.entity;

import java.io.Serializable;
import javax.persistence.*;

import org.hibernate.validator.constraints.Length;


/**
 * The persistent class for the t_notifications database table.
 * 
 */
@Entity
@NamedQueries({
	@NamedQuery(name = "fetchNotificationsByDocstoreId", query = "SELECT myTNotification from TNotification myTNotification where myTNotification.TDocstore.docstoreId = ?1 ")
})
@Table(name="t_notifications", uniqueConstraints = @UniqueConstraint(columnNames = { "notification_id"}))
public class TNotification implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "notification_id", nullable = false, length = 255)
	private int notificationId;
	
	@Length(max = 500)
	@Column(name = "notification_name", nullable = false, length = 500)
	private String notificationName;
	
	@Length(max = 100)
	@Column(name = "prefix", nullable = true, length = 100)
	private String prefix;
	
	@Length(max = 100)
	@Column(name = "suffix", nullable = true, length = 100)
	private String suffix;
	
	@OneToOne
	@JoinColumn(name = "docstore_id", referencedColumnName = "docstore_id", nullable = false, insertable = false, updatable = false)
	private TDocstore TDocstore;
	
	@OneToOne
	@JoinColumn(name = "event_id", referencedColumnName = "event_id", nullable = false, insertable = false, updatable = false)
	private TEvent TEvent;
	
	@Length(max = 1)
	@Column(name = "active_flag", nullable = false, length = 1)
	private char activeFlag;

	public TNotification() {
	}

	public int getNotificationId() {
		return this.notificationId;
	}

	public void setNotificationId(int notificationId) {
		this.notificationId = notificationId;
	}

	public String getNotificationName() {
		return this.notificationName;
	}

	public void setNotificationName(String notificationName) {
		this.notificationName = notificationName;
	}
	
	public char getActiveFlag() {
		return activeFlag;
	}

	public void setActiveFlag(char activeFlag) {
		this.activeFlag = activeFlag;
	}


	public String getPrefix() {
		return this.prefix;
	}

	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}


	public String getSuffix() {
		return this.suffix;
	}

	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	public TDocstore getTDocstore() {
		return this.TDocstore;
	}

	public void setTDocstore(TDocstore TDocstore) {
		this.TDocstore = TDocstore;
	}

	public TEvent getTEvent() {
		return this.TEvent;
	}

	public void setTEvent(TEvent TEvent) {
		this.TEvent = TEvent;
	}

}