package com.docstore.core.dao;

import java.util.List;

import com.docstore.core.entity.TNotification;

public interface TNotificationDAO {
	
	/**
	 * Stores a new TNotification entity object in to the persistent store
	 * 
	 * @param tNotification TNotification Entity object to be persisted
	 * @return tNotification Persisted TNotification object
	 */
	TNotification createTNotification(TNotification tNotification);

	/**
	 * Deletes a TNotification entity object from the persistent store
	 * 
	 * @param tNotification TNotification Entity object to be deleted
	 */
	void deleteTNotification(Integer tNotificationId);

	/**
	 * Updates a TNotification entity object in to the persistent store
	 * 
	 * @param tNotification TNotification Entity object to be updated
	 * @return tNotification Persisted TNotification object
	 */
	TNotification updateTNotification(TNotification tNotification);

	/**
	 * Retrieve an TNotification object based on given docstoreId.
	 * 
	 * @param tNotificationId the primary key value of the TNotification Entity.
	 * @return an Object if it exists against given primary key. Returns null of not found
	 */
	TNotification findTNotificationById(Integer tNotificationId);
	
	/**
	 * @param tDocstoreId
	 * @return
	 */
	List<TNotification> findTNotificationsByDocstoreId(Integer tDocstoreId); 
}
