package com.docstore.core.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.docstore.core.entity.TNotification;

@Repository("tNotificationDAO")
public class TNotificationDAOImpl implements TNotificationDAO{
	
	@Autowired
	private GenericDAO genericDAO;
	
	private final Class<TNotification> clazz;
	
	public TNotificationDAOImpl(){
		super();
		this.clazz = TNotification.class;
	}

	//@Override
	public TNotification createTNotification(TNotification tNotification) {
		System.out.println("=========== Create TNotification ===========");		
		return genericDAO.store(tNotification);
	}

	//@Override
	public void deleteTNotification(Integer tNotificationId) {
		System.out.println("=========== delete TNotification ===========");
		final TNotification tNotification = genericDAO.get(clazz, tNotificationId);
		genericDAO.remove(tNotification);
	}

	//@Override
	public TNotification updateTNotification(TNotification tNotification) {
		System.out.println("=========== Update TNotification ===========");
		return genericDAO.update(tNotification);
	}

	//@Override
	public TNotification findTNotificationById(Integer tNotificationId) {
		System.out.println("find TNotification with notificationId: " + tNotificationId);
		return genericDAO.get(clazz, tNotificationId);
	}

	//@Override
	public List<TNotification> findTNotificationsByDocstoreId(Integer tDocstoreId) {
		System.out.println("find TNotifications by docstoreId: " + tDocstoreId);
		List<Object> paramList = new ArrayList<Object>();
		paramList.add(tDocstoreId);
		return genericDAO.findEntitiesByNamedQueryMultiCond("fetchNotificationsByDocstoreId", paramList, 0, -1);
	}

}
