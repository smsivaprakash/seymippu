package com.docstore.sample.test;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.ClientConfiguration;
import com.amazonaws.Protocol;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.AbortMultipartUploadRequest;
import com.amazonaws.services.s3.model.CompleteMultipartUploadRequest;
import com.amazonaws.services.s3.model.CreateBucketRequest;
import com.amazonaws.services.s3.model.GetBucketLocationRequest;
import com.amazonaws.services.s3.model.InitiateMultipartUploadRequest;
import com.amazonaws.services.s3.model.InitiateMultipartUploadResult;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ListVersionsRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PartETag;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.PutObjectResult;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.amazonaws.services.s3.model.S3VersionSummary;
import com.amazonaws.services.s3.model.UploadPartRequest;
import com.amazonaws.services.s3.model.VersionListing;
import com.amazonaws.services.s3.transfer.Download;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.amazonaws.services.s3.transfer.Upload;

public class TestS3Services {

	public static void main(String[] args){
		AWSCredentials awsCredentials = new BasicAWSCredentials("AKIAIWOSXWNQUEYFMWQQ", "Y6GN+4xDQXKwqqJl1fi0mlXZcjYQeIC1JIDTyl4d");
		ClientConfiguration clientConfiguration = new ClientConfiguration();
		clientConfiguration.setProtocol(Protocol.HTTP);
		clientConfiguration.setProxyHost("proxy.cognizant.com");
		clientConfiguration.setProxyPort(6050);
		AmazonS3 s3client = new AmazonS3Client(awsCredentials, clientConfiguration);
		s3client.setRegion(Region.getRegion(Regions.AP_SOUTH_1));

		TestS3Services test = new TestS3Services();

		//list objects from a bucket
		test.listObjects("ilyareyter", s3client);

		//create new bucket
//		test.createBucket("sodhanai", s3client);

		//delete bucket
//		test.deleteBucket("sodhanairendu", s3client);

		//upload file
//		test.uploadFile("C:\\Users\\Siva prakash.S\\Desktop\\upload_prog.txt", "multiPart", "ilyareyter", s3client);

		//multi part upload
//		test.uploadMultiPart("C:\\Users\\Siva prakash.S\\Desktop\\upload_prog.txt", "multiPart", "ilyareyter", s3client);

		//download object
//		test.downloadObject("ilyareyter", "excel_upload.xlsx", "C:\\Users\\399536\\Downloads\\xl", s3client);
		
		//upload with transfer manager
//		test.uploadObject("neeku", "", s3client);
		
		//upload folder
//		test.createFolder("neeku","pudhuFolder/new",s3client);
	}

	private void listObjects(String bucketName, AmazonS3 s3client){
		ObjectListing objectListing = s3client.listObjects(new ListObjectsRequest().withBucketName(bucketName).withPrefix(""));
		List<S3ObjectSummary> objectSummaries = objectListing.getObjectSummaries();
		for(S3ObjectSummary summary : objectSummaries){
			System.out.println("===========================");
			System.out.println(summary.getKey()+"   "+summary.getSize()+"   "+summary.getLastModified());
			ObjectMetadata objectMetadata = s3client.getObjectMetadata(bucketName, summary.getKey());
			System.out.println("content: "+objectMetadata.getContentType()+" contLength: "+objectMetadata.getContentLength());
		}
	}

	private void createBucket(String bucketName, AmazonS3 s3client){
		try {
			if(!(s3client.doesBucketExist(bucketName)))
			{
				// Note that CreateBucketRequest does not specify region. So bucket is 
				// created in the region specified in the client.
				s3client.createBucket(new CreateBucketRequest(
						bucketName));
			}
			else{
				System.out.println("bucket: "+bucketName+" already exists");
			}
			// Get location.
			String bucketLocation = s3client.getBucketLocation(new GetBucketLocationRequest(bucketName));
			System.out.println("bucket location = " + bucketLocation);

		} catch (AmazonServiceException ase) {
			System.out.println("Caught an AmazonServiceException, which " +
					"means your request made it " +
					"to Amazon S3, but was rejected with an error response" +
					" for some reason.");
			System.out.println("Error Message:    " + ase.getMessage());
			System.out.println("HTTP Status Code: " + ase.getStatusCode());
			System.out.println("AWS Error Code:   " + ase.getErrorCode());
			System.out.println("Error Type:       " + ase.getErrorType());
			System.out.println("Request ID:       " + ase.getRequestId());
		} catch (AmazonClientException ace) {
			System.out.println("Caught an AmazonClientException, which " +
					"means the client encountered " +
					"an internal error while trying to " +
					"communicate with S3, " +
					"such as not being able to access the network.");
			System.out.println("Error Message: " + ace.getMessage());
		}
	}

	private void deleteBucket(String bucketName, AmazonS3 s3client){
		try {
			System.out.println("Deleting S3 bucket: " + bucketName);
			ObjectListing objectListing = s3client.listObjects(bucketName);

			while (true) {
				for (Iterator<?> iterator = objectListing.getObjectSummaries().iterator(); iterator.hasNext(); ) {
					S3ObjectSummary objectSummary = (S3ObjectSummary) iterator.next();
					s3client.deleteObject(bucketName, objectSummary.getKey());
				}

				if (objectListing.isTruncated()) {
					objectListing = s3client.listNextBatchOfObjects(objectListing);
				} else {
					break;
				}
			};
			VersionListing list = s3client.listVersions(new ListVersionsRequest().withBucketName(bucketName));
			for ( Iterator<?> iterator = list.getVersionSummaries().iterator(); iterator.hasNext(); ) {
				S3VersionSummary s = (S3VersionSummary)iterator.next();
				s3client.deleteVersion(bucketName, s.getKey(), s.getVersionId());
			}
			s3client.deleteBucket(bucketName);

		} catch (AmazonServiceException ase) {
			System.out.println("Caught an AmazonServiceException, which " +
					"means your request made it " +
					"to Amazon S3, but was rejected with an error response" +
					" for some reason.");
			System.out.println("Error Message:    " + ase.getMessage());
			System.out.println("HTTP Status Code: " + ase.getStatusCode());
			System.out.println("AWS Error Code:   " + ase.getErrorCode());
			System.out.println("Error Type:       " + ase.getErrorType());
			System.out.println("Request ID:       " + ase.getRequestId());
		} catch (AmazonClientException ace) {
			System.out.println("Caught an AmazonClientException, which " +
					"means the client encountered " +
					"an internal error while trying to " +
					"communicate with S3, " +
					"such as not being able to access the network.");
			System.out.println("Error Message: " + ace.getMessage());
		}
	}

	private void uploadFile(String uploadFileName, String keyName, String bucketName, AmazonS3 s3client){
		try {
			System.out.println("Uploading a new object to S3 from a file\n");
			File file = new File(uploadFileName);
			PutObjectResult result = s3client.putObject(new PutObjectRequest(bucketName, keyName, file));
			System.out.println("version: "+result.getVersionId());

		} catch (AmazonServiceException ase) {
			System.out.println("Caught an AmazonServiceException, which " +
					"means your request made it " +
					"to Amazon S3, but was rejected with an error response" +
					" for some reason.");
			System.out.println("Error Message:    " + ase.getMessage());
			System.out.println("HTTP Status Code: " + ase.getStatusCode());
			System.out.println("AWS Error Code:   " + ase.getErrorCode());
			System.out.println("Error Type:       " + ase.getErrorType());
			System.out.println("Request ID:       " + ase.getRequestId());
		} catch (AmazonClientException ace) {
			System.out.println("Caught an AmazonClientException, which " +
					"means the client encountered " +
					"an internal error while trying to " +
					"communicate with S3, " +
					"such as not being able to access the network.");
			System.out.println("Error Message: " + ace.getMessage());
		}
	}

	private void uploadMultiPart(String filePath, String keyName, String existingBucketName, AmazonS3 s3Client){
		// Create a list of UploadPartResponse objects. You get one of these
		// for each part upload.
		List<PartETag> partETags = new ArrayList<PartETag>();

		// Step 1: Initialize.
		InitiateMultipartUploadRequest initRequest = new 
				InitiateMultipartUploadRequest(existingBucketName, keyName);
		InitiateMultipartUploadResult initResponse = s3Client.initiateMultipartUpload(initRequest);

		File file = new File(filePath);
		long contentLength = file.length();
		long partSize = 5242880; // Set part size to 5 MB.

		try {
			// Step 2: Upload parts.
			long filePosition = 0;
			for (int i = 1; filePosition < contentLength; i++) {
				// Last part can be less than 5 MB. Adjust part size.
				partSize = Math.min(partSize, (contentLength - filePosition));

				// Create request to upload a part.
				UploadPartRequest uploadRequest = new UploadPartRequest()
				.withBucketName(existingBucketName).withKey(keyName)
				.withUploadId(initResponse.getUploadId()).withPartNumber(i)
				.withFileOffset(filePosition)
				.withFile(file)
				.withPartSize(partSize);

				// Upload part and add response to our list.
				partETags.add(
						s3Client.uploadPart(uploadRequest).getPartETag());

				filePosition += partSize;
			}

			// Step 3: Complete.
			CompleteMultipartUploadRequest compRequest = new 
					CompleteMultipartUploadRequest(
							existingBucketName, 
							keyName, 
							initResponse.getUploadId(), 
							partETags);

			s3Client.completeMultipartUpload(compRequest);
		} catch (Exception e) {
			s3Client.abortMultipartUpload(new AbortMultipartUploadRequest(
					existingBucketName, keyName, initResponse.getUploadId()));
		}
	}

	private void downloadObject(String bucketName, String key, String downloadPath, AmazonS3 s3Client){
		File file = new File(downloadPath);
		TransferManager transferManager = null;
		try{
			transferManager = new TransferManager(s3Client);
			Download download = transferManager.download(bucketName, key, file);
			download.waitForCompletion();
			if(download.isDone()){
				System.out.println("downloaded successfully");
			}
//			if(download.isDone() == false){
//				System.out.println("Transfer: " + download.getDescription());
//				System.out.println("  - State: " + download.getState());
//				System.out.println("  - Progress: " + download.getProgress().getBytesTransferred());
//			}
//			else{
//				System.out.println("downloaded successfully");
//			}
//			download.waitForCompletion();
		}
		catch(InterruptedException e){
			System.out.println("InterruptedException occured");
		} catch (AmazonServiceException ase) {
			System.out.println("Caught an AmazonServiceException, which " +
					"means your request made it " +
					"to Amazon S3, but was rejected with an error response" +
					" for some reason.");
			System.out.println("Error Message:    " + ase.getMessage());
			System.out.println("HTTP Status Code: " + ase.getStatusCode());
			System.out.println("AWS Error Code:   " + ase.getErrorCode());
			System.out.println("Error Type:       " + ase.getErrorType());
			System.out.println("Request ID:       " + ase.getRequestId());
		} catch (AmazonClientException ace) {
			System.out.println("Caught an AmazonClientException, which " +
					"means the client encountered " +
					"an internal error while trying to " +
					"communicate with S3, " +
					"such as not being able to access the network.");
			System.out.println("Error Message: " + ace.getMessage());
		}
		finally{
			transferManager.shutdownNow();
		}
	}
	
	private void uploadObject(String bucketName, String uploadPath, AmazonS3 s3Client){
		File file = new File(uploadPath);
		TransferManager transferManager = null;
		try{
			transferManager = new TransferManager(s3Client);
			InputStream inputStream = new FileInputStream("C:\\Users\\Siva prakash.S\\Desktop\\pudhusu.txt");
			ObjectMetadata objectMetadata = new ObjectMetadata();
			objectMetadata.setContentType("text/plain");
			Upload upload = transferManager.upload(bucketName, "pudhusu.txt", inputStream, objectMetadata);
			upload.waitForCompletion();
			if(upload.isDone()){
				System.out.println("uploaded successfully");
			}
		}
		catch(InterruptedException e){
			System.out.println("InterruptedException occured");
		} catch (AmazonServiceException ase) {
			System.out.println("Caught an AmazonServiceException, which " +
					"means your request made it " +
					"to Amazon S3, but was rejected with an error response" +
					" for some reason.");
			System.out.println("Error Message:    " + ase.getMessage());
			System.out.println("HTTP Status Code: " + ase.getStatusCode());
			System.out.println("AWS Error Code:   " + ase.getErrorCode());
			System.out.println("Error Type:       " + ase.getErrorType());
			System.out.println("Request ID:       " + ase.getRequestId());
		} catch (AmazonClientException ace) {
			System.out.println("Caught an AmazonClientException, which " +
					"means the client encountered " +
					"an internal error while trying to " +
					"communicate with S3, " +
					"such as not being able to access the network.");
			System.out.println("Error Message: " + ace.getMessage());
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			transferManager.shutdownNow();
		}
	}
	
	public void createFolder(String bucketName, String folderName, AmazonS3 s3Client){
		TransferManager transferManager = null;
		try{
			transferManager = new TransferManager(s3Client);
			InputStream inputStream = new ByteArrayInputStream(new byte[0]);
			ObjectMetadata objectMetadata = new ObjectMetadata();
			objectMetadata.setContentLength(0);
			//objectMetadata.setContentType("binary/octet-stream");
			Upload upload = transferManager.upload(bucketName, folderName+"/", inputStream, objectMetadata);
			upload.waitForCompletion();
			if(upload.isDone()){
				System.out.println("folder "+folderName+" uploaded successfully");
			}
		}
		catch (AmazonServiceException ase) {
			System.out.println("Caught an AmazonServiceException, which " +
					"means your request made it " +
					"to Amazon S3, but was rejected with an error response" +
					" for some reason.");
			System.out.println("Error Message:    " + ase.getMessage());
			System.out.println("HTTP Status Code: " + ase.getStatusCode());
			System.out.println("AWS Error Code:   " + ase.getErrorCode());
			System.out.println("Error Type:       " + ase.getErrorType());
			System.out.println("Request ID:       " + ase.getRequestId());
		} catch (AmazonClientException ace) {
			System.out.println("Caught an AmazonClientException, which " +
					"means the client encountered " +
					"an internal error while trying to " +
					"communicate with S3, " +
					"such as not being able to access the network.");
			System.out.println("Error Message: " + ace.getMessage());
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
