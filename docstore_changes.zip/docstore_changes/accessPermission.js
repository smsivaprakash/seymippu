$(document).ready(function() {
	var accTypeArray = [];
	accTypeArray[0] = "DEFAULT";
	accTypeArray[1] = "LIMITED";
	accTypeArray[2] = "FULLACCESS";
	$("#accessPerTbl tr:last td:last").on("click", function() {
		var accTypeSlct = '<select name="accessType" class="ui_btn" style="padding: 5px 10px;">';
		for(var j=0;j<accTypeArray.length;j++){
			accTypeSlct = accTypeSlct + '<option value="'+accTypeArray[j]+'" class="ui_optn">'+accTypeArray[j]+'</option>';
		}
		accTypeSlct = accTypeSlct + '</select>';
		//$(this).closest("td").remove();
		$(this).remove();
		$("#accessPerTbl tr:last").after("<tr><td><input type='text' value='' ></td><td>"+accTypeSlct+"</td><td><img src='http://localhost:8080/docucloud/assets/images/remove.jpg' class='accPerIcon' alt='remove' style='cursor:pointer' /></td><td><img src='http://localhost:8080/docucloud/assets/images/add.jpg' class='accPerIcon' alt='add' style='cursor:pointer' /></td></tr>");
		alert("in new js file");
		$.getScript("http://localhost:8080/docucloud/assets/js/accessPermission.js");
	});
});