package com.surveycloud.controller;

/**
 * @author Siva
 *
 */
public class SurveyAjaxController {

}
