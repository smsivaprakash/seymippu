/**
 * 
 */
package com.surveycloud.domain;

import java.io.Serializable;

/**
 * @author Siva
 *
 */
public class QuestionOption implements Serializable{

	private static final long serialVersionUID = -7612966963845743838L;
	
	private String optionIdentifier;
	private String optionDescription;
	
	/**
	 * @return the optionIdentifier
	 */
	public String getOptionIdentifier() {
		return optionIdentifier;
	}
	/**
	 * @param optionIdentifier the optionIdentifier to set
	 */
	public void setOptionIdentifier(String optionIdentifier) {
		this.optionIdentifier = optionIdentifier;
	}
	/**
	 * @return the optionDescription
	 */
	public String getOptionDescription() {
		return optionDescription;
	}
	/**
	 * @param optionDescription the optionDescription to set
	 */
	public void setOptionDescription(String optionDescription) {
		this.optionDescription = optionDescription;
	}
	

}
