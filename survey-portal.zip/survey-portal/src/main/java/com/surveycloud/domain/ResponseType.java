/**
 * 
 */
package com.surveycloud.domain;

/**
 * @author Siva
 *
 */
public enum ResponseType {
	
	RADIOBUTTON,
	CHECKBOX

}
