/**
 * 
 */
package com.surveycloud.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @author Siva
 *
 */
public class Survey implements Serializable{

	private static final long serialVersionUID = 3399660501183862653L;
	
	private long surveyId;
	private String surveyName;
	private String surveyDescription;
	private Date startDate;
	private Date endDate;
	private String recipientFile;
	private String attachmentFile;
	private User createdBy;
	private boolean isActive;
	private List<SurveyQuestion> surveyQuestions;
	
	/**
	 * @return the surveyId
	 */
	public long getSurveyId() {
		return surveyId;
	}
	/**
	 * @param surveyId the surveyId to set
	 */
	public void setSurveyId(long surveyId) {
		this.surveyId = surveyId;
	}
	/**
	 * @return the surveyName
	 */
	public String getSurveyName() {
		return surveyName;
	}
	/**
	 * @param surveyName the surveyName to set
	 */
	public void setSurveyName(String surveyName) {
		this.surveyName = surveyName;
	}
	/**
	 * @return the surveyDescription
	 */
	public String getSurveyDescription() {
		return surveyDescription;
	}
	/**
	 * @param surveyDescription the surveyDescription to set
	 */
	public void setSurveyDescription(String surveyDescription) {
		this.surveyDescription = surveyDescription;
	}
	/**
	 * @return the startDate
	 */
	public Date getStartDate() {
		return startDate;
	}
	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	/**
	 * @return the endDate
	 */
	public Date getEndDate() {
		return endDate;
	}
	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	/**
	 * @return the recipientFile
	 */
	public String getRecipientFile() {
		return recipientFile;
	}
	/**
	 * @param recipientFile the recipientFile to set
	 */
	public void setRecipientFile(String recipientFile) {
		this.recipientFile = recipientFile;
	}
	/**
	 * @return the attachmentFile
	 */
	public String getAttachmentFile() {
		return attachmentFile;
	}
	/**
	 * @param attachmentFile the attachmentFile to set
	 */
	public void setAttachmentFile(String attachmentFile) {
		this.attachmentFile = attachmentFile;
	}
	/**
	 * @return the createdBy
	 */
	public User getCreatedBy() {
		return createdBy;
	}
	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}
	/**
	 * @return the isActive
	 */
	public boolean isActive() {
		return isActive;
	}
	/**
	 * @param isActive the isActive to set
	 */
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	/**
	 * @return the surveyQuestions
	 */
	public List<SurveyQuestion> getSurveyQuestions() {
		return surveyQuestions;
	}
	/**
	 * @param surveyQuestions the surveyQuestions to set
	 */
	public void setSurveyQuestions(List<SurveyQuestion> surveyQuestions) {
		this.surveyQuestions = surveyQuestions;
	}

}
