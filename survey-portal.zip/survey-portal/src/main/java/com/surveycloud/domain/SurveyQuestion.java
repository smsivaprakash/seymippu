/**
 * 
 */
package com.surveycloud.domain;

import java.io.Serializable;
import java.util.List;

/**
 * @author Siva
 *
 */
public class SurveyQuestion implements Serializable{

	private static final long serialVersionUID = 5860495607030729547L;
	
	private long questionId;
	private String questionDescription;
	private boolean isMandatory;
	private ResponseType responseType;
	private int optionCount;
	private List<QuestionOption> questionOptions;
	
	/**
	 * @return the questionId
	 */
	public long getQuestionId() {
		return questionId;
	}
	/**
	 * @param questionId the questionId to set
	 */
	public void setQuestionId(long questionId) {
		this.questionId = questionId;
	}
	/**
	 * @return the questionDescription
	 */
	public String getQuestionDescription() {
		return questionDescription;
	}
	/**
	 * @param questionDescription the questionDescription to set
	 */
	public void setQuestionDescription(String questionDescription) {
		this.questionDescription = questionDescription;
	}
	/**
	 * @return the isMandatory
	 */
	public boolean isMandatory() {
		return isMandatory;
	}
	/**
	 * @param isMandatory the isMandatory to set
	 */
	public void setMandatory(boolean isMandatory) {
		this.isMandatory = isMandatory;
	}
	/**
	 * @return the responseType
	 */
	public ResponseType getResponseType() {
		return responseType;
	}
	/**
	 * @param responseType the responseType to set
	 */
	public void setResponseType(ResponseType responseType) {
		this.responseType = responseType;
	}
	/**
	 * @return the optionCount
	 */
	public int getOptionCount() {
		return optionCount;
	}
	/**
	 * @param optionCount the optionCount to set
	 */
	public void setOptionCount(int optionCount) {
		this.optionCount = optionCount;
	}
	/**
	 * @return the questionOptions
	 */
	public List<QuestionOption> getQuestionOptions() {
		return questionOptions;
	}
	/**
	 * @param questionOptions the questionOptions to set
	 */
	public void setQuestionOptions(List<QuestionOption> questionOptions) {
		this.questionOptions = questionOptions;
	}
	
	
}
