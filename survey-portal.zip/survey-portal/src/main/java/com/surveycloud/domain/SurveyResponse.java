/**
 * 
 */
package com.surveycloud.domain;

import java.io.Serializable;

/**
 * @author Siva
 *
 */
public class SurveyResponse implements Serializable{

	private static final long serialVersionUID = 5051178463707503439L;
	
	private long responseId;
	private Survey survey;
	private SurveyQuestion surveyQuestion;
	private String optionIdentifier;
	
	/**
	 * @return the responseId
	 */
	public long getResponseId() {
		return responseId;
	}
	/**
	 * @param responseId the responseId to set
	 */
	public void setResponseId(long responseId) {
		this.responseId = responseId;
	}
	/**
	 * @return the survey
	 */
	public Survey getSurvey() {
		return survey;
	}
	/**
	 * @param survey the survey to set
	 */
	public void setSurvey(Survey survey) {
		this.survey = survey;
	}
	/**
	 * @return the surveyQuestion
	 */
	public SurveyQuestion getSurveyQuestion() {
		return surveyQuestion;
	}
	/**
	 * @param surveyQuestion the surveyQuestion to set
	 */
	public void setSurveyQuestion(SurveyQuestion surveyQuestion) {
		this.surveyQuestion = surveyQuestion;
	}
	/**
	 * @return the optionIdentifier
	 */
	public String getOptionIdentifier() {
		return optionIdentifier;
	}
	/**
	 * @param optionIdentifier the optionIdentifier to set
	 */
	public void setOptionIdentifier(String optionIdentifier) {
		this.optionIdentifier = optionIdentifier;
	}
	

}
