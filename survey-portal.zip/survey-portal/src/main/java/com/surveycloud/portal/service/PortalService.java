package com.surveycloud.portal.service;

/**
 * @author Siva
 *
 */
public interface PortalService {

}
