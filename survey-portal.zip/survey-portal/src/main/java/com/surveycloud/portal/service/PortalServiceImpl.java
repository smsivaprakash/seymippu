package com.surveycloud.portal.service;

/**
 * @author Siva
 *
 */
public class PortalServiceImpl implements PortalService{

}
