/**
 * 
 */
package com.surveycloud.user.service;

/**
 * @author Siva
 *
 */
public interface UserService {

}
