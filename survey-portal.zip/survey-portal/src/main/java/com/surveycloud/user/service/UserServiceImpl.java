/**
 * 
 */
package com.surveycloud.user.service;

/**
 * @author Siva
 *
 */
public class UserServiceImpl implements UserService{

}
